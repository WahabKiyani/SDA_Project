package Test;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class scene1controller {

    @FXML
    private Button button2;

    @FXML
    private Button button1;

    @FXML
    void button1Action(ActionEvent event) {
        System.out.println("Hello");
    }

    @FXML
    void button2Action(ActionEvent event) {
        System.out.println("Siuuuu");
        try {
            Parent scene2Root = FXMLLoader.load(getClass().getResource("scene2.fxml"));
            Stage stage = (Stage) button2.getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @FXML
    void button3Action(ActionEvent event) {
    	System.out.println("Hello3");
    }
    
    
    
    @FXML
    void gotoscene1(ActionEvent event) {
    	try {
            Parent scene1Root = FXMLLoader.load(getClass().getResource("scene1.fxml"));
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene1Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
