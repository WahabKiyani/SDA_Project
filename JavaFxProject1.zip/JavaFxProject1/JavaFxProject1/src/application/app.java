package application;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import codingLayer.PrimaryController;
import codingLayer.codeHandler;


public class app extends Application {
    
    public PrimaryController primaryController;
    
    @Override
    public void start(Stage primaryStage) {
        try {
        	codeHandler code_handle=new codeHandler();
        	//code_handle.establishConnection();
        	
        	primaryController=new PrimaryController();
        	code_handle.setPrimaryController(primaryController);
        	primaryController.set_codeHandler(code_handle);
        	primaryController.db.ui_starter(primaryStage);
        	
        	 	
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}






