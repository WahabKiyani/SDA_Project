package databaseHandler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Item;
import model.Antique;
import model.Art;
import model.AuctionReport;
import model.Car;
import model.Electronic;


public class userDB{
	
public static Connection conn;
	
	public userDB(Connection conn)
	{
		this.conn=conn;
	}
	
	public ObservableList displayUserBids(int userID) {
        ObservableList<String> bidDetails = FXCollections.observableArrayList();

        String query = """
            SELECT 
    b.bidID,
    t.itemName, 
    b.amount, 
    b.timePlaced
FROM 
    Bid b
JOIN 
    Bidder i ON b.bidderID = i.bidderID
JOIN 
    Item t ON b.itemID = t.itemID
WHERE 
    i.userID = ? 
    AND b.bidID = (
        SELECT MAX(bidID) 
        FROM Bid 
        WHERE itemID = t.itemID 
        AND bidderID = b.bidderID
    )
    AND t.statuss = 'Available'
ORDER BY 
    b.timePlaced DESC;

            """;

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userID);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int bidID = rs.getInt("bidID");
                    String itemID = rs.getString("itemName");
                    double amount = rs.getDouble("amount");
                    String timePlaced = rs.getString("timePlaced");

                    // Format bid details for display
                    String bidInfo = String.format(
                        "Bid ID: %d | Item: %s | Amount: %.2f | Time: %s",
                        bidID, itemID, amount, timePlaced
                    );

                    bidDetails.add(bidInfo);
                }
                return bidDetails;
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
		return bidDetails;

        // Update the ListView with bid details
       
    }
	
	// Method to retrieve item details by itemID
    public static Item getItemDetails(int bidID) {
        String sql = "SELECT i.itemName, i.category, i.description, i.startingPrice, i.currentPrice,i.itemID,i.statuss FROM Item i JOIN Bid b ON i.itemID=b.itemID WHERE bidID = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, bidID);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String itemName = rs.getString("itemName");
                String category = rs.getString("category");
                String description = rs.getString("description");
                float startingPrice = rs.getFloat("startingPrice");
                float currentPrice = rs.getFloat("currentPrice");
                int id = rs.getInt("itemID");
                String status=rs.getString("statuss");
                
                if ("Car".equals(category)) {
                    System.out.println(category);
                    Car temp = new Car();
                    temp.setDetails(id, itemName, description, startingPrice, currentPrice,status);
                    return temp;
                }

               // return new Car(itemID, itemName, description, category, startingPrice, currentPrice);
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public static Item getItem(int itemID) {
        String sql = "SELECT i.itemName, i.category, i.description, i.startingPrice, i.currentPrice,i.itemID,i.statuss FROM Item i  WHERE i.itemID = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, itemID);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String itemName = rs.getString("itemName");
                String category = rs.getString("category");
                String description = rs.getString("description");
                float startingPrice = rs.getFloat("startingPrice");
                float currentPrice = rs.getFloat("currentPrice");
                int id = rs.getInt("itemID");
                String status=rs.getString("statuss");
                
                if ("Car".equals(category)) {
                    System.out.println(category);
                    Car temp = new Car();
                    temp.setDetails(id, itemName, description, startingPrice, currentPrice,status);
                    return temp;
                }
                else if ("Electronic".equals(category)) {
                    System.out.println(category);
                    Electronic temp = new Electronic();
                    temp.setDetails(id, itemName, description, startingPrice, currentPrice,status);
                    return temp;
                }
                else if ("Art".equals(category)) {
                    System.out.println(category);
                    Art temp = new Art();
                    temp.setDetails(id, itemName, description, startingPrice, currentPrice,status);
                    return temp;
                }
                else if ("Antique".equals(category)) {
                    System.out.println(category);
                    Antique temp = new Antique();
                    temp.setDetails(id, itemName, description, startingPrice, currentPrice,status);
                    return temp;
                }

               // return new Car(itemID, itemName, description, category, startingPrice, currentPrice);
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Method to place a new bid
    public static boolean placeBid(int bidderID, int itemID, float bidAmount) {
        // Insert new bid into Bid table
        String bidSQL = "INSERT INTO Bid (bidID,bidderID, itemID, amount, timePlaced) VALUES (?,?, ?, ?, ?)";
        String itemSQL = "UPDATE Item SET currentPrice = ? WHERE itemID = ?";
        
        try (PreparedStatement bidPs = conn.prepareStatement(bidSQL);
             PreparedStatement itemPs = conn.prepareStatement(itemSQL)) {

        	int temp=getNextBidId();
            // Insert the bid into the Bid table
        	bidPs.setInt(1,temp);
            bidPs.setInt(2, bidderID);
            bidPs.setInt(3, itemID);
            bidPs.setFloat(4, bidAmount);
            bidPs.setTimestamp(5, new Timestamp(System.currentTimeMillis()));

            int bidRows = bidPs.executeUpdate();

            // If the bid was inserted successfully, update the current price in the Item table
            if (bidRows > 0) {
                itemPs.setFloat(1, bidAmount);
                itemPs.setInt(2, itemID);
                itemPs.executeUpdate();
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
 // Method to place a new bid
    public static boolean addToBidder(int userID) {
        // Insert new bid into Bid table
        String bidSQL = "INSERT INTO Bidder (bidderID,userID) VALUES (?,?)";
       
        
        try (PreparedStatement bidPs = conn.prepareStatement(bidSQL)) {

        	int temp=getNextBidderId();
            // Insert the bid into the Bid table
        	bidPs.setInt(1,temp);
            bidPs.setInt(2, userID);
            

            int bidRows = bidPs.executeUpdate();

            
            if (bidRows > 0) {
                
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public static int getBidderIDByUserID(int userID) {
        String sql = "SELECT bidderID FROM Bidder WHERE userID = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userID);
            ResultSet rs = ps.executeQuery();

            // Check if there is a result
            if (rs.next()) {
                return rs.getInt("bidderID");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;  // Return -1 if no bidderID found for the given userID
    }

    
    public static int getNextBidId() throws SQLException {
	    String maxIdQuery = "SELECT ISNULL(MAX(bidID), 0) + 1 AS nextBidId FROM Bid";
	    try (PreparedStatement stmt = conn.prepareStatement(maxIdQuery);
	         ResultSet rs = stmt.executeQuery()) {
	        if (rs.next()) {
	            return rs.getInt("nextBidId");
	        }
	    }
	    // In case there's a problem fetching the next logID
	    throw new SQLException("Failed to generate the next Bid ID.");
	}
    
    public static int getNextBidderId() throws SQLException {
	    String maxIdQuery = "SELECT ISNULL(MAX(bidderID), 0) + 1 AS nextBidderId FROM Bidder";
	    try (PreparedStatement stmt = conn.prepareStatement(maxIdQuery);
	         ResultSet rs = stmt.executeQuery()) {
	        if (rs.next()) {
	            return rs.getInt("nextBidderId");
	        }
	    }
	    // In case there's a problem fetching the next logID
	    throw new SQLException("Failed to generate the next Bidder ID.");
	}

    // Method to validate if the new bid is greater than the current price and starting price
    public static boolean isValidBid(int itemID, float bidAmount) {
        String sql = "SELECT startingPrice, currentPrice FROM Item WHERE itemID = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, itemID);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                float startingPrice = rs.getFloat("startingPrice");
                float currentPrice = rs.getFloat("currentPrice");

                return bidAmount > startingPrice && bidAmount > currentPrice;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Method to retrieve the current bidder ID (this could be based on the logged-in user)
    public static int getCurrentBidderID() {
        // Implement logic to get the current logged-in bidder ID
        return 1; // Placeholder for simplicity
    }
    
    
    public int addSeller(int userID) {
        try {
            // Step 1: Calculate new sellerID
            String countQuery = "SELECT MAX(sellerID) AS total FROM Seller";
            PreparedStatement countStmt = conn.prepareStatement(countQuery);
            ResultSet countResult = countStmt.executeQuery();

            int newSellerID = 1; // Default value if no sellers exist
            if (countResult.next()) {
                newSellerID = countResult.getInt("total") + 1;
            }

            // Step 2: Insert new seller record
            String insertQuery = "INSERT INTO Seller (sellerID, userID) VALUES (?, ?)";
            PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
            insertStmt.setInt(1, newSellerID);
            insertStmt.setInt(2, userID);

            int rowsAffected = insertStmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Seller added successfully with ID: " + newSellerID);
                return newSellerID;
            } else {
                System.out.println("Failed to add the seller.");
                return -1;
            }

            // Close resources
           // countStmt.close();
            //insertStmt.close();

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error occurred while adding seller.");
        }
		return -1;
    }
	
    
 // Function to add a new item to the database
    public void addItem(String name, String category, String description, double startingPrice, int sellerID) {
     
        PreparedStatement stmt = null;
        ResultSet rs = null;
        int newItemID = 0;

        try {
            

            // Step 1: Get the current highest itemID and calculate the next itemID
            String getMaxItemIDQuery = "SELECT MAX(itemID) AS maxItemID FROM Item";
            stmt = conn.prepareStatement(getMaxItemIDQuery);
            rs = stmt.executeQuery();

            if (rs.next()) {
                newItemID = rs.getInt("maxItemID") + 1; // Incrementing the max itemID by 1
            } else {
                newItemID = 1; // If no items exist, start with itemID = 1
            }

            // Step 2: Insert the new item into the database
            String insertItemQuery = "INSERT INTO Item (itemID, itemName, description, startingPrice, currentPrice, statuss, sellerID, category) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

            stmt = conn.prepareStatement(insertItemQuery);
            stmt.setInt(1, newItemID);
            stmt.setString(2, name);
            stmt.setString(3, description);
            stmt.setDouble(4, startingPrice);
            stmt.setDouble(5, startingPrice); // Set currentPrice equal to startingPrice initially
            stmt.setString(6, "Pending"); // Default status
            stmt.setInt(7, sellerID);
            stmt.setString(8, category);

            // Execute the insert
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Item added successfully!");
            } else {
                System.out.println("Failed to add item.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        
    }
    
    public int insertBid(int bidderID, int itemID, float amount) {
        // Database connection variables
      
        PreparedStatement stmt = null;
        ResultSet rs = null;
        int newBidID = 0;

        try {
        

            // Query to get the maximum bidID from the Bid table
            String countQuery = "SELECT MAX(bidID) + 1 AS newBidID FROM Bid";

            // Create a statement
            stmt = conn.prepareStatement(countQuery);
            rs = stmt.executeQuery();

            // Retrieve the new bidID
            if (rs.next()) {
                newBidID = rs.getInt("newBidID");
            }

            // Query to insert the new bid into the Bid table
            String insertQuery = "INSERT INTO Bid (bidID, bidderID, itemID, amount, timePlaced) VALUES (?, ?, ?, ?, GETDATE())";
            

            // Prepare the insert statement
            stmt = conn.prepareStatement(insertQuery);
            stmt.setInt(1, newBidID);
            stmt.setInt(2, bidderID);
            stmt.setInt(3, itemID);
            stmt.setFloat(4, amount);

            // Execute the insert query
            stmt.executeUpdate();

            // Return the new bidID
            return newBidID;

        } catch (SQLException e) {
            e.printStackTrace();
            return -1; // Indicate an error
        } 
        
}
    
    public static int getBidderIDByUserID2(int userID) {
        // First, check if a bidderID already exists for the given userID
        String sql = "SELECT bidderID FROM Bidder WHERE userID = ?";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userID);
            ResultSet rs = ps.executeQuery();

            // If a bidderID is found, return it
            if (rs.next()) {
                return rs.getInt("bidderID");
            }

            // If no bidderID found, insert a new bidder
            String maxBidderQuery = "SELECT MAX(bidderID) + 1 AS newBidderID FROM Bidder";
            try (PreparedStatement maxPs = conn.prepareStatement(maxBidderQuery);
                 ResultSet maxRs = maxPs.executeQuery()) {
                
                // Get the new bidderID (max + 1)
                int newBidderID = 0;
                if (maxRs.next()) {
                    newBidderID = maxRs.getInt("newBidderID");
                }

                // Now, insert the new bidder into the Bidder table
                String insertBidderQuery = "INSERT INTO Bidder (bidderID, userID) VALUES (?, ?)";
                try (PreparedStatement insertPs = conn.prepareStatement(insertBidderQuery)) {
                    insertPs.setInt(1, newBidderID);
                    insertPs.setInt(2, userID);
                    insertPs.executeUpdate();
                }

                // Return the new bidderID
                return newBidderID;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1; // Return -1 in case of error
    }
    
   

    // Method to fetch items by category
    public static ObservableList<String> getItemsByCategory(String category) {
        ObservableList<String> items = FXCollections.observableArrayList();

        String query = "SELECT itemID,itemName, currentPrice FROM Item WHERE category = ? ORDER BY itemName ASC, currentPrice ASC";

        try (
             PreparedStatement preparedStatement = conn.prepareStatement(query)) {

            // Set the category parameter
            preparedStatement.setString(1, category);

            // Execute the query
            ResultSet resultSet = preparedStatement.executeQuery();

            // Add results to the ObservableList
            while (resultSet.next()) {
            	int itemID=resultSet.getInt("itemID");
                String itemName = resultSet.getString("itemName");
                double currentPrice = resultSet.getDouble("currentPrice");
                items.add(itemID +" - "+ itemName + " - " + currentPrice);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return items;
    }
    
    public static void updateCurrentPrice(int itemID, float currentPrice) throws SQLException {
        // Establish connection to the database
       

        // SQL query to update current price
        String updateQuery = "UPDATE Item SET currentPrice = ? WHERE itemID = ?";

        try (PreparedStatement preparedStatement = conn.prepareStatement(updateQuery)) {
            // Set the parameters
            preparedStatement.setFloat(1, currentPrice);
            preparedStatement.setInt(2, itemID);

            
            // Execute the update query
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Successfully updated current price for item ID: " + itemID);
            } else {
                System.out.println("No item found with item ID: " + itemID);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Error updating current price for item ID: " + itemID, e);
        }
    }
    
    
    
    public static List<AuctionReport> getAuctionReportsByBidderId(int bidderID) {
        List<AuctionReport> reports = new ArrayList<>();
        String query = "SELECT reportID, reportDate, price, sellerID, itemID, description, name " +
                       "FROM AuctionReport WHERE bidderID = ?";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, bidderID);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int seller_id = rs.getInt("sellerID");
                int item_id = rs.getInt("itemID");
                float price = rs.getFloat("price");
                String description = rs.getString("description");
                String name = rs.getString("name");

                // Create an AuctionReport object
                AuctionReport report = new AuctionReport(seller_id, item_id, bidderID, price, description, name);

                // Optionally set the reportID and reportDate if needed
                report.setReportID(rs.getInt("reportID"));
                report.setReportDate(rs.getTimestamp("reportDate"));

                // Add to the list
                reports.add(report);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return reports;
    }
    
    
    public static List<AuctionReport> getAuctionReportsBysellerId(int bidderID) {
        List<AuctionReport> reports = new ArrayList<>();
        String query = "SELECT reportID, reportDate, price, sellerID, itemID, description, name " +
                       "FROM AuctionReport WHERE sellerID = ?";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, bidderID);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int seller_id = rs.getInt("sellerID");
                int item_id = rs.getInt("itemID");
                float price = rs.getFloat("price");
                String description = rs.getString("description");
                String name = rs.getString("name");

                // Create an AuctionReport object
                AuctionReport report = new AuctionReport(bidderID, item_id, seller_id, price, description, name);

                // Optionally set the reportID and reportDate if needed
                report.setReportID(rs.getInt("reportID"));
                report.setReportDate(rs.getTimestamp("reportDate"));

                // Add to the list
                reports.add(report);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return reports;
    }
    
    public String getBidderNameById(int bidderID) {
        String query = "SELECT u.name FROM Bidder b JOIN Users u ON b.userID = u.userID WHERE b.bidderID = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, bidderID);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("name");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; // Return null if bidder not found
    }
    public String getSellerNameById(int sellerID) {
        String query = "SELECT u.name FROM Seller s JOIN Users u ON s.userID = u.userID WHERE s.sellerID = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, sellerID);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("name");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; // Return null if seller not found
    }
    public String getItemNameById(int itemID) {
        String query = "SELECT itemName FROM Item WHERE itemID = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, itemID);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("itemName");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; // Return null if item not found
    }

}