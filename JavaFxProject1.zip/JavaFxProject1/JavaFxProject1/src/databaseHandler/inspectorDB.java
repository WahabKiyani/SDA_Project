package databaseHandler;

//import java.security.Timestamp;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

import java.sql.Timestamp;
import java.time.ZoneId;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class inspectorDB{
public static Connection conn;
	
	public inspectorDB(Connection conn)
	{
		this.conn=conn;
	}
	
	
	public ObservableList<String> getPendingItems() {
	    String query = "SELECT itemID, itemName, description FROM Item WHERE statuss = 'Pending'";
	    ObservableList<String> pendingItems = FXCollections.observableArrayList();

	    try (PreparedStatement stmt = conn.prepareStatement(query);
	         ResultSet rs = stmt.executeQuery()) {

	        while (rs.next()) {
	            int itemID = rs.getInt("itemID");
	            String itemName = rs.getString("itemName");
	            String description = rs.getString("description");

	            pendingItems.add("ID: " + itemID + ", Name: " + itemName + ", Description: " + description);
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return pendingItems;
	}
	
	
	public ObservableList<String> getInprogressItems() {
	    String query = "SELECT itemID, itemName, description FROM Item WHERE statuss = 'InProgress'";
	    ObservableList<String> pendingItems = FXCollections.observableArrayList();

	    try (PreparedStatement stmt = conn.prepareStatement(query);
	         ResultSet rs = stmt.executeQuery()) {

	        while (rs.next()) {
	            int itemID = rs.getInt("itemID");
	            String itemName = rs.getString("itemName");
	            String description = rs.getString("description");

	            pendingItems.add("ID: " + itemID + ", Name: " + itemName + ", Description: " + description);
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return pendingItems;
	}
	
	public ObservableList<String> getBookedItems() {
	    String query = "SELECT itemID, itemName, description FROM Item WHERE statuss IN ('Cancel', 'Available')";
	    ObservableList<String> pendingItems = FXCollections.observableArrayList();

	    try (PreparedStatement stmt = conn.prepareStatement(query);
	         ResultSet rs = stmt.executeQuery()) {

	        while (rs.next()) {
	            int itemID = rs.getInt("itemID");
	            String itemName = rs.getString("itemName");
	            String description = rs.getString("description");

	            pendingItems.add("ID: " + itemID + ", Name: " + itemName + ", Description: " + description);
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return pendingItems;
	}
	
	
	 public boolean setItemStatusToInProgress(int itemID) {
	        String updateQuery = "UPDATE Item SET statuss = 'InProgress' WHERE itemID = ?";

	        try (PreparedStatement stmt = conn.prepareStatement(updateQuery)) {

	            // Set the itemID in the query
	            stmt.setInt(1, itemID);

	            // Execute the update
	            int rowsAffected = stmt.executeUpdate();

	            // If at least one row is updated, the operation was successful
	            return rowsAffected > 0;

	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        return false;
	    }
	 
	 
	 public boolean setItemStatusToActive(int itemID,int amount) {
		    String updateQuery = "UPDATE Item SET statuss = 'Available', auctionEndTime = ? , currentPrice=? , startingPrice=?  WHERE itemID = ?";

		    try (PreparedStatement stmt = conn.prepareStatement(updateQuery)) {
		        // Calculate the current time plus 10 hours
		        LocalDateTime currentTimePlus10Hours = LocalDateTime.now().plusHours(10);

		        // Convert LocalDateTime to Timestamp
		        Timestamp auctionEndTime = Timestamp.valueOf(currentTimePlus10Hours);

		        // Set parameters in the query
		        stmt.setTimestamp(1, auctionEndTime); // auctionEndTime
		        stmt.setInt(2, amount);              // itemID
		        stmt.setInt(3, amount);
		        stmt.setInt(4,itemID);
		        // Execute the update
		        int rowsAffected = stmt.executeUpdate();

		        // Return true if at least one row was updated
		        return rowsAffected > 0;

		    } catch (Exception e) {
		        e.printStackTrace();
		    }

		    return false;
		}
	 
	 
	 public boolean setItemStatusToCancel(int itemID) {
	        String updateQuery = "UPDATE Item SET statuss = 'Cancel' WHERE itemID = ?";

	        try (PreparedStatement stmt = conn.prepareStatement(updateQuery)) {

	            // Set the itemID in the query
	            stmt.setInt(1, itemID);

	            // Execute the update
	            int rowsAffected = stmt.executeUpdate();

	            // If at least one row is updated, the operation was successful
	            return rowsAffected > 0;

	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        return false;
	    }
	 
	 public void setItemSold() {
	        // Get current time (formatted properly for SQL)
	        Timestamp currentTime = getCurrentTime();

	        // Query to find items where auctionEndTime has passed and status is not 'Sold' or 'Unsold'
	        String query = "SELECT itemID, auctionEndTime, statuss FROM Item WHERE auctionEndTime < ? AND statuss NOT IN ('Sold', 'Unsold')";

	        try (PreparedStatement stmt = conn.prepareStatement(query)) {
	            stmt.setTimestamp(1, currentTime); // Set the current time for comparison
	            ResultSet rs = stmt.executeQuery();

	            // Iterate over all items whose auction has ended
	            while (rs.next()) {
	                int itemID = rs.getInt("itemID");
	                Timestamp auctionEndTime = rs.getTimestamp("auctionEndTime"); // Correctly using Timestamp here

	                // Check if there were any bids for this item
	                boolean hasBids = checkIfItemHasBids(itemID);

	                if (hasBids) {
	                    // Create auction report and set the item status to 'Sold'
	                    createAuctionReport(itemID);
	                    updateItemStatus(itemID, "Sold");
	                } else {
	                    // If no bids, set item status to 'Unsold'
	                    updateItemStatus(itemID, "Unsold");
	                }
	            }

	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    private Timestamp getCurrentTime() {
	        // Return current time as Timestamp, this will work with SQL Server's DATETIME type
	        return new Timestamp(System.currentTimeMillis());
	    }

	    private boolean checkIfItemHasBids(int itemID) {
	        String query = "SELECT COUNT(*) FROM Bid WHERE itemID = ?";
	        try (PreparedStatement stmt = conn.prepareStatement(query)) {
	            stmt.setInt(1, itemID);
	            ResultSet rs = stmt.executeQuery();
	            if (rs.next()) {
	                return rs.getInt(1) > 0;
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return false;
	    }

	    private void createAuctionReport(int itemID) {
	    	
	    	String namee;
	        // Fetch details for the auction report (e.g., price, bidderID, sellerID)
	        String query = "SELECT i.itemName,b.bidderID, i.sellerID, b.amount, b.timePlaced " +
	                       "FROM Bid b JOIN Item i ON b.itemID = i.itemID WHERE b.itemID = ?";

	        try (PreparedStatement stmt = conn.prepareStatement(query)) {
	            stmt.setInt(1, itemID);
	            ResultSet rs = stmt.executeQuery();

	            if (rs.next()) {
	            	namee=rs.getString("itemName");
	                int bidderID = rs.getInt("bidderID");
	                int sellerID = rs.getInt("sellerID");
	                float price = rs.getFloat("amount");
	                Timestamp timePlaced = rs.getTimestamp("timePlaced");  // Use Timestamp for time handling
	                String description = "Bid placed by bidderID " + bidderID + " on " + timePlaced;

	                // Fetch the last reportID from the AuctionReport table and increment by 1
	                String maxReportIDQuery = "SELECT MAX(reportID) FROM AuctionReport";
	                int reportID = 1;  // Default to 1 if no reports exist yet
	                try (PreparedStatement maxStmt = conn.prepareStatement(maxReportIDQuery)) {
	                    ResultSet maxRs = maxStmt.executeQuery();
	                    if (maxRs.next()) {
	                        reportID = maxRs.getInt(1) + 1;  // Increment the last reportID by 1
	                    }
	                }

	                // Create the AuctionReport with the new reportID
	                String insertReport = "INSERT INTO AuctionReport (reportID, reportDate, price, bidderID, sellerID, itemID, description,name) " +
	                                      "VALUES (?, ?, ?, ?, ?, ?, ?,?)";
	                try (PreparedStatement insertStmt = conn.prepareStatement(insertReport)) {
	                    insertStmt.setInt(1, reportID);  // Set the new reportID
	                    insertStmt.setTimestamp(2, new Timestamp(System.currentTimeMillis()));  // reportDate as current timestamp
	                    insertStmt.setFloat(3, price);    // price
	                    insertStmt.setInt(4, bidderID);  // bidderID
	                    insertStmt.setInt(5, sellerID);  // sellerID
	                    insertStmt.setInt(6, itemID);    // itemID
	                    insertStmt.setString(7, description);  // description
	                    insertStmt.setString(8, namee);

	                    insertStmt.executeUpdate();
	                }
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    private void updateItemStatus(int itemID, String status) {
	        String updateQuery = "UPDATE Item SET statuss = ? WHERE itemID = ?";
	        try (PreparedStatement stmt = conn.prepareStatement(updateQuery)) {
	            stmt.setString(1, status);
	            stmt.setInt(2, itemID);
	            stmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	}
