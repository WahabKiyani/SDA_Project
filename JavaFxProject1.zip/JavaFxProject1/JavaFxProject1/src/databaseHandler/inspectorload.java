package databaseHandler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import model.Inspector;
import model.User;

public class inspectorload{
	
public static Connection conn;
	
	public inspectorload(Connection conn)
	{
		this.conn=conn;
	}

	public static Inspector getUserDetailsByID(int userID) {
	    String sql = "SELECT * FROM Inspector WHERE inspectorID = ?";
	  
		try (PreparedStatement ps = conn.prepareStatement(sql)) {
	        ps.setInt(1, userID);
	        ResultSet rs = ps.executeQuery();

	        // Check if a result is found
	        if (rs.next()) {
	            String name = rs.getString("name");
	            String email = rs.getString("email");
	            String password = rs.getString("password");
	            String status = rs.getString("statuss");
	            String phoneNumber = rs.getString("phoneNumber");
	            Timestamp regTime = rs.getTimestamp("Reg_time");

	            // Create a User object and set the retrieved details
	            Inspector user = new Inspector();
	            user.register(userID, name, phoneNumber,email,password );
	            return user;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null;  // Return null if no user is found for the given userID
	}
}