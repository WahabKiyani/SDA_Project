package databaseHandler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import model.User;
import model.Antique;
import model.Art;
import model.Bid;
import model.Car;
import model.Electronic;
import model.Item;

public class userload{
	
public static Connection conn;
	
	public userload(Connection conn)
	{
		this.conn=conn;
	}
	
	
	public static User getUserDetailsByID(int userID) {
	    String sql = "SELECT * FROM Users WHERE userID = ?";
	  
		try (PreparedStatement ps = conn.prepareStatement(sql)) {
	        ps.setInt(1, userID);
	        ResultSet rs = ps.executeQuery();

	        // Check if a result is found
	        if (rs.next()) {
	            String name = rs.getString("name");
	            String email = rs.getString("email");
	            String password = rs.getString("password");
	            String status = rs.getString("statuss");
	            String phoneNumber = rs.getString("phoneNumber");
	            Timestamp regTime = rs.getTimestamp("Reg_time");

	            // Create a User object and set the retrieved details
	            User user = new User();
	            user.register(userID, name, email, password, phoneNumber);
	            return user;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null;  // Return null if no user is found for the given userID
	}

	public static int getBidderIDByUserID(int userID) {
	    String sql = "SELECT bidderID FROM Bidder WHERE userID = ?";
	    try (PreparedStatement ps = conn.prepareStatement(sql)) {
	        ps.setInt(1, userID);  // Set userID parameter
	        ResultSet rs = ps.executeQuery();

	        if (rs.next()) {
	            return rs.getInt("bidderID");  // Return bidderID if found
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();  // Handle any SQL errors
	    }
	    return -1;  // Return null if no bidderID is found
	}
	
	public static int getSellerIDByUserID(int userID) {
	    String sql = "SELECT sellerID FROM Seller WHERE userID = ?";
	    try (PreparedStatement ps = conn.prepareStatement(sql)) {
	        ps.setInt(1, userID);  // Set userID parameter
	        ResultSet rs = ps.executeQuery();

	        if (rs.next()) {
	            return rs.getInt("sellerID");  // Return sellerID if found
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();  // Handle any SQL errors
	    }
	    return -1;  // Return null if no sellerID is found
	}
	
	public List<Item> getItemsBySellerID(int sellerID) {
        List<Item> items = new ArrayList<>();

        String sql = "SELECT itemID, itemName, description, startingPrice, currentPrice, statuss, auctionEndTime, category "
                   + "FROM Item WHERE sellerID = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, sellerID);
            ResultSet rs = ps.executeQuery();

           
            while (rs.next()) {
                int itemID = rs.getInt("itemID");
                String itemName = rs.getString("itemName");
                String description = rs.getString("description");
                float startingPrice = rs.getFloat("startingPrice");
                float currentPrice = rs.getFloat("currentPrice");
                String status = rs.getString("statuss");
                Timestamp auctionEndTime = rs.getTimestamp("auctionEndTime");
                String category = rs.getString("category");

                // Create an Item object for each row
                Item item=null;
                if(category.equals("Car"))
                {
                	item=new Car();
                	item.setDetails(itemID, itemName, description, startingPrice, currentPrice,status);
                }
                else if(category.equals("Art"))
                {
                	item=new Art();
                	item.setDetails(itemID, itemName, description, startingPrice, currentPrice,status);
                }
                else if(category.equals("Electronic"))
                {
                	item=new Electronic();
                	item.setDetails(itemID, itemName, description, startingPrice, currentPrice,status);
                	System.out.println("Electronic added.");
                }
                else if(category.equals("Antique"))
                {
                	item=new Antique();
                	item.setDetails(itemID, itemName, description, startingPrice, currentPrice,status);
                }
                
                
                items.add(item);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return items;
    }
	
	public List<Bid> getAllBidsByBidderID(int bidderID) {
        String sql = "SELECT bidID, itemID, amount, timePlaced FROM Bid WHERE bidderID = ?";
        List<Bid> bids = new ArrayList<>();

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, bidderID);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int bidID = rs.getInt("bidID");
                int itemID = rs.getInt("itemID");
                float amount = rs.getFloat("amount");
                Timestamp timePlaced = rs.getTimestamp("timePlaced");

                // Create a new Bid object and add it to the list
                bids.add(new Bid(bidID, bidderID, itemID, amount, timePlaced));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return bids;
    }


}