package databaseHandler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class adminDB{
	private Connection conn;
	
	public adminDB(Connection c)
	{
		this.conn=c;
		
	}
	
	public ObservableList<String> getUserList() {
        String query = "SELECT userID, name , email,password,phoneNumber  FROM Users";
        ObservableList<String> userList = FXCollections.observableArrayList();

        try (
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int userID = rs.getInt("userID");
                String userName = rs.getString("name");
                String userEmail = rs.getString("email");
                String pass =rs.getString("password");
                String phoneNumber =rs.getString("phoneNumber");

                // Add formatted user details to the list
                userList.add("ID: " + userID + ", Name: " + userName + ", Email: " + userEmail + ", Pass: " + pass + ", Phone Number: " + phoneNumber);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return userList;
    }
	
	
	public ObservableList<String> getInspectorList() {
        String query = "SELECT inspectorID, name , email,password,phoneNumber  FROM Inspector";
        ObservableList<String> userList = FXCollections.observableArrayList();

        try (
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int userID = rs.getInt("inspectorID");
                String userName = rs.getString("name");
                String userEmail = rs.getString("email");
                String pass =rs.getString("password");
                String phoneNumber =rs.getString("phoneNumber");

                // Add formatted user details to the list
                userList.add("ID: " + userID + ", Name: " + userName + ", Email: " + userEmail + ", Pass: " + pass + ", Phone Number: " + phoneNumber);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return userList;
    }
	
	public ObservableList<String> getitemmsList() {
        String query = "SELECT itemID, itemName , sellerID,currentPrice ,statuss  FROM Item";
        ObservableList<String> userList = FXCollections.observableArrayList();

        try (
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int itemID = rs.getInt("itemID");
                String itemName = rs.getString("itemName");
                int sellerID = rs.getInt("sellerID");
                //String description =rs.getString("description");
                int currentPrice =rs.getInt("currentPrice");
                String statuss=rs.getString("statuss");

                // Add formatted user details to the list
                userList.add("ID: " + itemID + ", Name: " + itemName + ", SellerID: " + sellerID + ", CurrentPrice: " + currentPrice + ",Status: " + statuss);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return userList;
    }
	
	public ObservableList<String> getLogs() {
        String query = "SELECT logID,action,performedBy,timestamp  FROM Log";
        ObservableList<String> userList = FXCollections.observableArrayList();

        try (
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int logID = rs.getInt("logID");
                String action = rs.getString("action");
                String performedBy = rs.getString("performedBy");
                String timestamp =rs.getString("timestamp");

                // Add formatted user details to the list
                userList.add("ID: " + logID + ", Action: " + action + ", performedBy: " + performedBy + ", timestamp: " + timestamp);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return userList;
    }
	
	
	
}