package databaseHandler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import model.Admin;
import model.Inspector;
import model.User;

public class adminload{
	
public static Connection conn;
	
	public adminload(Connection conn)
	{
		this.conn=conn;
	}

	public static Admin getUserDetailsByID(int userID) {
	    String sql = "SELECT * FROM Admin WHERE adminID = ?";
	  
		try (PreparedStatement ps = conn.prepareStatement(sql)) {
	        ps.setInt(1, userID);
	        ResultSet rs = ps.executeQuery();

	        // Check if a result is found
	        if (rs.next()) {
	            String name = rs.getString("name");
	            String email = rs.getString("email");
	            String password = rs.getString("password");
	            String phoneNumber = rs.getString("phoneNumber");
	            Timestamp regTime = rs.getTimestamp("Reg_time");

	            // Create a User object and set the retrieved details
	            Admin user = new Admin();
	            user.register(userID, name, phoneNumber,email,password );
	            return user;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null;  // Return null if no user is found for the given userID
	}
}