package databaseHandler;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class authentication{
	
	public static Connection conn;
	
	public authentication(Connection conn)
	{
		this.conn=conn;
	}
	
	public int authenticateUser(String email, String password) throws SQLException {
	    // Check if the connection is valid
	    if (conn == null || conn.isClosed()) {
	        System.out.println("Connection is closed. Reinitializing...");
	        this.reinitializeConnection();
	    }

	    // Query to authenticate user
	    String query = "SELECT userID FROM Users WHERE email = ? AND password = ? AND statuss = 'Active'";
	    String logQuery = "INSERT INTO Log (logID, action, performedBy, timestamp) VALUES (?, ?, ?, GETDATE())";

	    try (PreparedStatement stmt = conn.prepareStatement(query);
	         PreparedStatement logStmt = conn.prepareStatement(logQuery)) {

	        // Set parameters for user authentication
	        stmt.setString(1, email);
	        stmt.setString(2, password);

	        // Execute query
	        try (ResultSet rs = stmt.executeQuery()) {
	            if (rs.next()) {
	                // Retrieve and return userID
	                int userId = rs.getInt("userID");

	                // Generate a unique logID by incrementing the current maximum logID
	                int logId = getNextLogId(); // Method to get the next logID

	                // Log the authentication action
	                logStmt.setInt(1, logId);
	                logStmt.setString(2, "User Login");
	                logStmt.setString(3, email); // Use email or userID as performedBy
	                logStmt.executeUpdate();

	                return userId;
	            }
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    // Return -1 if authentication fails
	    return -1;
	}
	
	
	private int getNextLogId() throws SQLException {
	    String maxIdQuery = "SELECT ISNULL(MAX(logID), 0) + 1 AS nextLogId FROM Log";
	    try (PreparedStatement stmt = conn.prepareStatement(maxIdQuery);
	         ResultSet rs = stmt.executeQuery()) {
	        if (rs.next()) {
	            return rs.getInt("nextLogId");
	        }
	    }
	    // In case there's a problem fetching the next logID
	    throw new SQLException("Failed to generate the next log ID.");
	}


	
	public int authenticateAdmin(String email, String password) throws SQLException {
	    // Check if the connection is valid
	    if (conn == null || conn.isClosed()) {
	        System.out.println("Connection is closed. Reinitializing...");
	        this.reinitializeConnection();
	    }

	    String query = "SELECT adminID FROM Admin WHERE email = ? AND password = ?"; // Ensure the account is active
	    String logQuery = "INSERT INTO Log (logID, action, performedBy, timestamp) VALUES (?, ?, ?, GETDATE())";

	    try (PreparedStatement stmt = conn.prepareStatement(query);
	         PreparedStatement logStmt = conn.prepareStatement(logQuery)) {

	        // Set parameters for admin authentication
	        stmt.setString(1, email);
	        stmt.setString(2, password);

	        // Execute query
	        try (ResultSet rs = stmt.executeQuery()) {
	            if (rs.next()) {
	                // Retrieve and return adminID
	                int adminId = rs.getInt("adminID");

	                // Generate a unique logID by incrementing the current maximum logID
	                int logId = getNextLogId(); // Method to get the next logID

	                // Log the authentication action
	                logStmt.setInt(1, logId);
	                logStmt.setString(2, "Admin Login");
	                logStmt.setString(3, email); // Use email as performedBy (or adminID if you prefer)
	                logStmt.executeUpdate();

	                return adminId; // Return the adminID if authentication is successful
	            }
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    // Return -1 if authentication fails
	    return -1;
	}


	
	public int authenticateInspector(String email, String password) throws SQLException {
	    // Check if the connection is valid
	    if (conn == null || conn.isClosed()) {
	        System.out.println("Connection is closed. Reinitializing...");
	        this.reinitializeConnection();
	    }

	    // Query to authenticate inspector
	    String query = "SELECT inspectorID FROM Inspector WHERE email = ? AND password = ? AND statuss = 'Active'";
	    String logQuery = "INSERT INTO Log (logID, action, performedBy, timestamp) VALUES (?, ?, ?, GETDATE())";

	    try (PreparedStatement stmt = conn.prepareStatement(query);
	         PreparedStatement logStmt = conn.prepareStatement(logQuery)) {

	        // Set parameters for inspector authentication
	        stmt.setString(1, email);
	        stmt.setString(2, password);

	        // Execute query
	        try (ResultSet rs = stmt.executeQuery()) {
	            if (rs.next()) {
	                // Retrieve and return inspectorID
	                int inspectorId = rs.getInt("inspectorID");

	                // Generate a unique logID by incrementing the current maximum logID
	                int logId = getNextLogId(); // Method to get the next logID

	                // Log the authentication action
	                logStmt.setInt(1, logId);
	                logStmt.setString(2, "Inspector Login");
	                logStmt.setString(3, email); // Use email as performedBy (or inspectorID if you prefer)
	                logStmt.executeUpdate();

	                return inspectorId; // Return the inspectorID if authentication is successful
	            }
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    // Return -1 if authentication fails
	    return -1;
	}


	
	
	
	public int signupUser(String name, String email, String password) {
	    String checkQuery = "SELECT COUNT(*) FROM Users WHERE email = ?";
	    String maxIdQuery = "SELECT ISNULL(MAX(userID), 0) FROM Users"; // Get the maximum userID or default to 0
	    String insertQuery = "INSERT INTO Users (userID, name, email, password, statuss, Reg_time) VALUES (?, ?, ?, ?, 'Active', GETDATE())";
	    String logQuery = "INSERT INTO Log (logID,action, performedBy, timestamp) VALUES (?,?, ?, GETDATE())"; // Log the action

	    try (PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
	         PreparedStatement maxIdStmt = conn.prepareStatement(maxIdQuery);
	         PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
	         PreparedStatement logStmt = conn.prepareStatement(logQuery)) {

	        // Check if the email already exists
	        checkStmt.setString(1, email);
	        try (ResultSet rs = checkStmt.executeQuery()) {
	            if (rs.next() && rs.getInt(1) > 0) {
	                System.out.println("Error: User with the same email already exists.");
	                return -1;
	            }
	        }

	        // Retrieve the next userID
	        int nextUserId = 1001; // Default starting point
	        try (ResultSet rs = maxIdStmt.executeQuery()) {
	            if (rs.next()) {
	                nextUserId = rs.getInt(1) + 1; // Add 1 to the maximum userID
	            }
	        }

	        // Insert the new user
	        insertStmt.setInt(1, nextUserId); // Set userID
	        insertStmt.setString(2, name);
	        insertStmt.setString(3, email);
	        insertStmt.setString(4, password);

	        int rowsInserted = insertStmt.executeUpdate();
	        if (rowsInserted > 0) {
	            System.out.println("User registered successfully with userID: " + nextUserId);

	            // Log the signup action
	            int logId = getNextLogId();
	            
	            logStmt.setInt(1, logId);
	            logStmt.setString(2, "User Signup");
	            logStmt.setString(3, email); // Or specify the name of the admin/system performing the action
	            logStmt.executeUpdate();

	            return nextUserId;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return -1;
	}


	
	public int signupAdmin(String name, String email, String password) {
	    String checkQuery = "SELECT COUNT(*) FROM Admin WHERE email = ?";
	    String maxIdQuery = "SELECT ISNULL(MAX(adminID), 0) FROM Admin"; // Get the maximum userID or default to 0
	    String insertQuery = "INSERT INTO Admin (adminID, name, email, password, Reg_time) VALUES (?, ?, ?, ?, GETDATE())";
	    String logQuery = "INSERT INTO Log (logID,action, performedBy, timestamp) VALUES (?,?, ?, GETDATE())"; // Log the action

	    try (PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
	         PreparedStatement maxIdStmt = conn.prepareStatement(maxIdQuery);
	         PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
	         PreparedStatement logStmt = conn.prepareStatement(logQuery)) {

	        // Check if the email already exists
	        checkStmt.setString(1, email);

	        try (ResultSet rs = checkStmt.executeQuery()) {
	            if (rs.next() && rs.getInt(1) > 0) {
	                System.out.println("Error: User with the same email already exists.");
	                return -1;
	            }
	        }

	        // Retrieve the next userID
	        int nextUserId = 1; // Default starting point
	        try (ResultSet rs = maxIdStmt.executeQuery()) {
	            if (rs.next()) {
	                nextUserId = rs.getInt(1) + 1; // Add 1 to the maximum userID
	            }
	        }

	        // Insert the new user
	        insertStmt.setInt(1, nextUserId); // Set userID
	        insertStmt.setString(2, name);
	        insertStmt.setString(3, email);
	        insertStmt.setString(4, password);

	        int rowsInserted = insertStmt.executeUpdate();
	        if (rowsInserted > 0) {
	            System.out.println("Admin registered successfully with AdminID: " + nextUserId);
	            
                 int logId = getNextLogId();
	            
	            logStmt.setInt(1, logId);
	            logStmt.setString(2, "Admin Signup");
	            logStmt.setString(3, email); // Or specify the name of the admin/system performing the action
	            logStmt.executeUpdate();
	            
	            
	            return nextUserId;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return -1;
	}
	
	
	public int signupInspector(String name, String email, String password) {
	    String checkQuery = "SELECT COUNT(*) FROM Inspector WHERE email = ?";
	    String maxIdQuery = "SELECT ISNULL(MAX(inspectorID), 0) FROM Inspector"; // Get the maximum userID or default to 0
	    String insertQuery = "INSERT INTO Inspector (inspectorID, name, email, password,statuss, Reg_time) VALUES (?, ?, ?, ?,'Active', GETDATE())";
	    String logQuery = "INSERT INTO Log (logID,action, performedBy, timestamp) VALUES (?,?, ?, GETDATE())"; // Log the action
	    try (PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
	         PreparedStatement maxIdStmt = conn.prepareStatement(maxIdQuery);
	         PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
	    		 PreparedStatement logStmt = conn.prepareStatement(logQuery)) {

	        // Check if the email already exists
	        checkStmt.setString(1, email);

	        try (ResultSet rs = checkStmt.executeQuery()) {
	            if (rs.next() && rs.getInt(1) > 0) {
	                System.out.println("Error: User with the same email already exists.");
	                return -1;
	            }
	        }

	        // Retrieve the next userID
	        int nextUserId = 1; // Default starting point
	        try (ResultSet rs = maxIdStmt.executeQuery()) {
	            if (rs.next()) {
	                nextUserId = rs.getInt(1) + 1; // Add 1 to the maximum userID
	            }
	        }

	        // Insert the new user
	        insertStmt.setInt(1, nextUserId); // Set userID
	        insertStmt.setString(2, name);
	        insertStmt.setString(3, email);
	        insertStmt.setString(4, password);

	        int rowsInserted = insertStmt.executeUpdate();
	        if (rowsInserted > 0) {
	            System.out.println("Inspector registered successfully with userID: " + nextUserId);
	            
	            
 int logId = getNextLogId();
	            
	            logStmt.setInt(1, logId);
	            logStmt.setString(2, "Inspector Signup");
	            logStmt.setString(3, email); // Or specify the name of the admin/system performing the action
	            logStmt.executeUpdate();
	            return nextUserId;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return -1;
	}


	
	public void reinitializeConnection() {
        // NOTE: in the connection string:
        // - Change FTCLAPTOP-13 to the name of your SQL Server.
        // - Change Learners to the name of your database in SQL Server.

		String connectionString = 
		        "jdbc:sqlserver://LAPTOP-PANDA\\SQLEXPRESS;Database=SDA_Proj;IntegratedSecurity=true;encrypt=false;trustServerCertificate=true;";

		    try {
		        // Establish connection
		        this.conn = DriverManager.getConnection(connectionString);
		        System.out.println("Connection established.");
		    } catch (SQLException e) {
		        System.out.println("Error connecting to the database");
		        e.printStackTrace();
		    }
    }
	
	
	public void insertLog(String action, String performedByEmail) {
     
        PreparedStatement stmt = null;
        ResultSet rs = null;
        int newLogID = 0;

        try {
            // Establish connection to the database (replace with actual DB details)
     

            // Step 1: Get the current highest logID and calculate the next logID
            String getMaxLogIDQuery = "SELECT MAX(logID) AS maxLogID FROM Log";
            stmt = conn.prepareStatement(getMaxLogIDQuery);
            rs = stmt.executeQuery();

            if (rs.next()) {
                newLogID = rs.getInt("maxLogID") + 1; // Incrementing the max logID by 1
            } else {
                newLogID = 1; // If no logs exist, start with logID = 1
            }

            // Step 2: Insert the new log into the database
            String insertLogQuery = "INSERT INTO Log (logID, action, performedBy, timestamp) "
                    + "VALUES (?, ?, ?, GETDATE())";

            stmt = conn.prepareStatement(insertLogQuery);
            stmt.setInt(1, newLogID);
            stmt.setString(2, action);
            stmt.setString(3, performedByEmail);

            
            // Get the current timestamp
           // Timestamp timestamp = new Timestamp(new Date().getTime());
          //  stmt.setTimestamp(4, timestamp);

            // Execute the insert
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Log inserted successfully!");
            } else {
                System.out.println("Failed to insert log.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } 
        }
    
	public boolean saveNewInfo(String name, String password,String email) {
        try {
            // Example database update query (use your actual DB code here)
            String sql = "UPDATE Users SET name = ?, password = ? WHERE email = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, password);
            ps.setString(3, email); // Email is unique and cannot be changed
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
	
	
	public boolean saveNewInfoInspector(String name, String password,String email) {
        try {
            // Example database update query (use your actual DB code here)
            String sql = "UPDATE Inspector SET name = ?, password = ? WHERE email = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, password);
            ps.setString(3, email); // Email is unique and cannot be changed
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
	
	
	public boolean saveNewInfoAdmin(String name, String password,String email) {
        try {
            // Example database update query (use your actual DB code here)
            String sql = "UPDATE Admin SET name = ?, password = ? WHERE email = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, password);
            ps.setString(3, email); // Email is unique and cannot be changed
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
	
	
	 public static String getRegistrationDate(int userId) {
	        String registrationDate = null;

	        String query = "SELECT Reg_time FROM Users WHERE userID = ?";

	        try (PreparedStatement ps = conn.prepareStatement(query)) {
	            ps.setInt(1, userId);

	            try (ResultSet rs = ps.executeQuery()) {
	                if (rs.next()) {
	                    registrationDate = rs.getString("Reg_time");
	                }
	            }

	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

	        return registrationDate;
	    }

	 public static String getRegistrationDateInspector(int userId) {
	        String registrationDate = null;

	        String query = "SELECT Reg_time FROM Inspector WHERE inspectorID = ?";

	        try (PreparedStatement ps = conn.prepareStatement(query)) {
	            ps.setInt(1, userId);

	            try (ResultSet rs = ps.executeQuery()) {
	                if (rs.next()) {
	                    registrationDate = rs.getString("Reg_time");
	                }
	            }
	       
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

	        return registrationDate;
	    }
	 
	 public static String getRegistrationDateAdmin(int userId) {
	        String registrationDate = null;

	        String query = "SELECT Reg_time FROM Admin WHERE adminID = ?";

	        try (PreparedStatement ps = conn.prepareStatement(query)) {
	            ps.setInt(1, userId);

	            try (ResultSet rs = ps.executeQuery()) {
	                if (rs.next()) {
	                    registrationDate = rs.getString("Reg_time");
	                }
	            }

	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

	        return registrationDate;
	    }
}