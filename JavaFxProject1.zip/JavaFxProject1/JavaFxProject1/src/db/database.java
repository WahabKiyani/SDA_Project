package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.ByteArrayInputStream;


public class database {

	public Connection connection;
	
	public database() {
        // NOTE: in the connection string:
        // - Change FTCLAPTOP-13 to the name of your SQL Server.
        // - Change Learners to the name of your database in SQL Server.

		String connectionString = 
		        "jdbc:sqlserver://LAPTOP-PANDA\\SQLEXPRESS;Database=SDA_Proj;IntegratedSecurity=true;encrypt=false;trustServerCertificate=true;";

		    try {
		        // Establish connection
		        this.connection = DriverManager.getConnection(connectionString);
		        System.out.println("Connection established.");
		    } catch (SQLException e) {
		        System.out.println("Error connecting to the database");
		        e.printStackTrace();
		    }
    }
	
	
}