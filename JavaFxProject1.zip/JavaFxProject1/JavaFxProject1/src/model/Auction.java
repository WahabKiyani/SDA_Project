package model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import model.Bidder;

public class Auction {
    private int auctionID;
    private Date startTime;
    private Date endTime;
    private String auctionType; // Example: "English", "Sealed-Bid"
    private List<Bidder> observers; // Observers pattern
    private String status;

    // Constructor
    public Auction(int auctionID, Date startTime, Date endTime, String auctionType) {
        this.auctionID = auctionID;
        this.startTime = startTime;
        this.endTime = endTime;
        this.auctionType = auctionType;
        this.status = "Scheduled";
        this.observers = new ArrayList<>();
    }

    // Start auction
    public void startAuction() {
        this.status = "Ongoing";
        sendNotifications("Auction Started");
    }

    // Close auction
    public void closeAuction() {
        this.status = "Closed";
        sendNotifications("Auction Closed");
    }

    // Send notifications to bidders
    private void sendNotifications(String message) {
        for (Bidder bidder : observers) {
            //Notification notification = new Notification( message, new Date());
          //  bidder.viewNotifications().add(notification);
        }
    }

    private static String generateID() {
        return "AUC-" + System.currentTimeMillis();
    }
}
