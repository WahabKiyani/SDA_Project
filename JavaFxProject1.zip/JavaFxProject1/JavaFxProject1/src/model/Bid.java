package model;

import java.util.Date;

public class Bid {
    private int bidID;
    private int Bidder_id;
    private int item_id;
    private float amount;
    private Date timePlaced;
  

    // Constructor
    public Bid(int id,int Bidder_id, int item_id,float amount, Date timePlaced) {
        this.bidID = id;
        this.amount = amount;
        this.timePlaced = timePlaced;
  
        this.Bidder_id = Bidder_id;
        this.item_id=item_id;
    }

    // Validate bid
    public boolean validateBid() {
        // Business rules for bid validation
        return amount > 0;
    }

    

  
    public float getAmount() {
        return amount;
    }
}
