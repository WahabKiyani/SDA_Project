package model;

public interface Notifiable {
    void viewNotifications();
    void sendNotification(String message);
}
