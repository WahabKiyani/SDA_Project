package model;

import java.util.Date;

public class Log {
    private int logID;
    private String action; // e.g., "User Login", "Item Approved"
    private String performedBy; // e.g., "Admin", "Inspector", or User ID
    private Date timestamp;

    // Constructor
    public Log(int logID, String action, String performedBy) {
        this.logID = logID;
        this.action = action;
        this.performedBy = performedBy;
        this.timestamp = new Date();
    }

    // Getters
    public int getLogID() {
        return logID;
    }

    public String getAction() {
        return action;
    }

    public String getPerformedBy() {
        return performedBy;
    }

    public Date getTimestamp() {
        return timestamp;
    }
}
