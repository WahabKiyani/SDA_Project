package model;

import java.util.Date;

public class AuctionReport {
    private int reportID;
    private Date reportDate;
    private float price;
    private int bidder_id;
    private int seller_id;
    private int item_id;
    private String descrption;
    private String name;
    
    

    // Constructor
    public AuctionReport( int seller_id,int item_id,int bidder_id,float price,String descrption,String name) {
      //  this.reportID = reportID;
        this.setReportDate(new Date());
        this.setBidder_id(bidder_id);
        this.setSeller_id(seller_id);
        this.setPrice(price);
        this.setDescrption(descrption);
        this.name=name;
        this.setItem_id(item_id);
        

    }

    // Generate report
    public void generate() {
        // Logic to generate report
    }

	public int getReportID() {
		return reportID;
	}

	public void setReportID(int reportID) {
		this.reportID = reportID;
	}

	public Date getReportDate() {
		return reportDate;
	}

	public void setReportDate(Date reportDate) {
		this.reportDate = reportDate;
	}

	public String getDescrption() {
		return descrption;
	}

	public void setDescrption(String descrption) {
		this.descrption = descrption;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getItem_id() {
		return item_id;
	}

	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}

	public int getSeller_id() {
		return seller_id;
	}

	public void setSeller_id(int seller_id) {
		this.seller_id = seller_id;
	}

	public int getBidder_id() {
		return bidder_id;
	}

	public void setBidder_id(int bidder_id) {
		this.bidder_id = bidder_id;
	}
}
