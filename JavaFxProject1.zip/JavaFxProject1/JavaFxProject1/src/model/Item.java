package model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public abstract class Item {
    private int itemID;
    private String itemName;
    private String description;
    private float startingPrice;
    private float currentPrice;
    protected String status;
    protected Date auctionEndTime;
    protected List<Bid> bids;
    protected float system_charges;
	private String category;

	Item()
	{
		
	}
    // Constructor
    public Item(int itemID, String itemName, String description, float startingPrice, Date auctionEndTime) {
        this.setItemID(itemID);
        this.setItemName(itemName);
        this.setDescription(description);
        this.setStartingPrice(startingPrice);
        this.setCurrentPrice(startingPrice);
        this.status = "Pending Approval";
        this.auctionEndTime = auctionEndTime;
        this.bids = new ArrayList<>();
        

    }
    public void setDetails(int itemID, String itemName, String description, float startingPrice, float currentPrice,String s)
	{
		this.setItemID(itemID);
		this.setItemName(itemName);
		this.setDescription(description);
		this.setStartingPrice(startingPrice);
		this.setCurrentPrice(currentPrice);
		this.status=s;
	}

    // Add a bid to the item
    public void addBid(Bid bid) {
        if (bid.validateBid()) {
            bids.add(bid);
            setCurrentPrice(bid.getAmount()); // Update the current price
        }
    }

    // Update item details
    public void updateDetails(String newDetails) {
        this.setDescription(newDetails);
    }

    public String getStatus() {
        return status;
    }

    public Date getAuctionEndTime() {
        return auctionEndTime;
    }
    
    public abstract float charges();
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getItemID() {
		return itemID;
	}
	public void setItemID(int itemID) {
		this.itemID = itemID;
	}
	public float getStartingPrice() {
		return startingPrice;
	}
	public void setStartingPrice(float startingPrice) {
		this.startingPrice = startingPrice;
	}
	public float getCurrentPrice() {
		return currentPrice;
	}
	public void setCurrentPrice(float currentPrice) {
		this.currentPrice = currentPrice;
	}
    
}





