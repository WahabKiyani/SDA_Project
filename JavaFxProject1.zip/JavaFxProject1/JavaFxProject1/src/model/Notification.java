package model;

import java.util.Date;

public class Notification {
    private int notificationID;
    private String message;
    private Date timestamp;
    private int user_id;


    // Constructor
    public Notification( String message, Date timestamp,int user_id) {
        this.message = message;
        this.timestamp = timestamp;
        this.user_id=user_id;
        
    }



    // Getters
    public String getMessage() {
        return message;
    }

    public Date getTimestamp() {
        return timestamp;
    }
}
