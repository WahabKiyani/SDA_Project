package model;

import java.util.Date;

public class Car extends Item
{
	public Car()
	{
		super();
		this.setCategory("Car");
	}
	Car(int itemID, String itemName, String description, float startingPrice, Date auctionEndTime)
	{
		super( itemID,  itemName,  description,  startingPrice,  auctionEndTime);
		this.setCategory("Car");
	}
	
	public void setDetails(int itemID, String itemName, String description, float startingPrice, float currentPrice,String s)
	{
		this.setItemID(itemID);
		this.setItemName(itemName);
		this.setDescription(description);
		this.setStartingPrice(startingPrice);
		this.setCurrentPrice(currentPrice);
		this.status=s;
	}
	
	
	public float charges()
	{
		return 0;
	}
};
