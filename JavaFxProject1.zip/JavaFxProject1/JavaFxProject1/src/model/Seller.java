package model;

import java.util.List;

public class Seller  {
	public List<Item> items;
    // Constructor
  
	private int sellerID;
	public Seller(int n)
    {
    	this.setSellerID(n);
    }

    // List an item for auction
    public void listItemForAuction(Item item) {
        item.updateDetails("Listed for Auction");
    }

    // Generate auction report
    public AuctionReport generateAuctionReport(List<Item> soldItems) {
        float totalSales = 0;
        return null;
    }

    // View notifications (implementation of abstract method)
  /*  @Override
    public void viewNotifications() {
        // Logic to display notifications for the seller
        System.out.println("Viewing notifications for seller: " + name);
    }
*/
    private static String generateID() {
        return "SELL-" + System.currentTimeMillis();
    }

	public int getSellerID() {
		return sellerID;
	}

	public void setSellerID(int sellerID) {
		this.sellerID = sellerID;
	}
}

