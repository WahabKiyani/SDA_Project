package model;

public interface UserActions {
    void register(int userID,String name, String email, String password,String ph);
    boolean login(String email, String password);
    void updateProfile(String newDetails);
}
