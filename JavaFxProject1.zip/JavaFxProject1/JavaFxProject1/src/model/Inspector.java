package model;

import java.util.Date;

 class InspectionReport {
    private int reportID;
    private int inspector_id;
    private String findings;
    private float marketValue;
    private Date inspectionDate;

    // Constructor
    public InspectionReport(int reportID, String findings, float marketValue,int inspector_id) {
        this.reportID = reportID;
        this.findings = findings;
        this.marketValue = marketValue;
        this.inspectionDate = new Date();
        this.inspector_id=inspector_id;
        
    }
}

 public class Inspector {
	    private int inspectorID;
	    private String name;
	    private String contactInfo;
	    private String email;
	    private String password;


	    // Constructor
	    public Inspector(int inspectorID, String name, String email, String password) {
	        this.inspectorID = inspectorID;
	        this.name = name;
	        this.email = email;
	        this.password = password;
	    }

	    public Inspector() {
			// TODO Auto-generated constructor stub
		}

		// Inspect item
	    public InspectionReport inspectItem(Item item, String findings, float marketValue) {
	     //   return new InspectionReport(generateID(), findings, marketValue);
	    	return null ;
	    }

	    // Account-related methods

	    // Register inspector
	    public void register(int inspectorID, String name, String contactInfo, String email, String password) {
	        this.inspectorID = inspectorID;
	        this.name = name;
	        this.contactInfo = contactInfo;
	        this.email = email;
	        this.password = password;
	    }

	    // Login
	    public boolean login(String email, String password) {
	        return this.email.equals(email) && this.password.equals(password);
	    }

	    // Update profile
	    public void updateProfile(String newName, String newContactInfo) {
	        this.name = newName;
	        this.contactInfo = newContactInfo;
	    }

	    // Getters
	    public int getInspectorID() {
	        return inspectorID;
	    }

	    public String getName() {
	        return name;
	    }

	    public String getContactInfo() {
	        return contactInfo;
	    }

	    public String getEmail() {
	        return email;
	    }


	    private static String generateID() {
	        return "INSP-" + System.currentTimeMillis();
	    }

		public String getPhoneNumber() {
			// TODO Auto-generated method stub
			return this.contactInfo;
		}

		public String getPassword() {
			// TODO Auto-generated method stub
			return this.password;
		}
	}

