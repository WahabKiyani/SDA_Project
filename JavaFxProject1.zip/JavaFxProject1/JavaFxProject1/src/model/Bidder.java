package model;
import java.util.ArrayList;
import java.util.List;

public class Bidder {
	public int bidderID;
    private List<Item> watchlist;
    public List<Bid> bid_placed;

    // Constructor

    public Bidder(int n)
    {
    	this.bidderID=n;
    }

    // Add item to watchlist
    public void addToWatchlist(Item item) {
        watchlist.add(item);
    }

    // Remove item from watchlist
    public void removeFromWatchlist(Item item) {
        watchlist.remove(item);
    }

    

    // View notifications (implementation of abstract method)
   // @Override
  /*  public void viewNotifications() {
        // Logic to display notifications for the bidder
        System.out.println("Viewing notifications for bidder: " + name);
    }
*/
    
}
