package codingLayer;

import java.sql.Connection;

import controller.chooseRole;
import db.database;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class codeHandler  {
	
	public PrimaryController primaryController;
	public Connection connection;
	
	public codeHandler()
	{
	//	primaryController=new PrimaryController();
	}
	
	public void setPrimaryController(PrimaryController pc)
	{
		this.primaryController=pc;
	}
    
    public void ui_starter(Stage primaryStage) {
        try {
       	    
        	primaryController.establishConnection();
            // Load the FXML file and link it to the SampleController
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/chooseRole.fxml"));
            
            Parent root = loader.load(); // Load the FXML file
            
            chooseRole controller = loader.getController();
            controller.setPrimaryController(primaryController);
            
            // Create the scene and set it to the stage
            Scene scene = new Scene(root);
            primaryStage.setTitle("JavaFX with Controller");
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void establishConnection() {
        try {
        	database db=new database();
        	this.connection=db.connection;

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
   
}