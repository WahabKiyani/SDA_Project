package codingLayer;

import java.sql.Connection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import databaseHandler.authentication;
import databaseHandler.inspectorload;
import db.database;
import model.Admin;
import model.Bidder;
import model.Inspector;
//import handlers.AuthenticationHandler;
//import repositories.PersonRepository;
import model.User;
import databaseHandler.userDB;
import databaseHandler.inspectorDB;
import databaseHandler.userload;
import databaseHandler.adminDB;
import databaseHandler.adminload;

public class PrimaryController
{
	public codeHandler db;
	public authentication auth;
	public userDB userDB;
	public inspectorDB inspectorDB;
	public adminDB adminDB;
	public User user;
	public Inspector inspector;
	public inspectorload Inspectorload;
	public adminload adminload;
	public Admin admin;
	public userload Userload;
	public int userID;
	public int inspectorID;
	
	//private final PersonRepository personRepo;
	//private final AuthenticationHandler authHandler;
	
	//public final AuthenticationController authController;
	
	//private final UserHomePageController userHomeController;
	public Connection connection;
	public int adminID;
	
	public void set_codeHandler(codeHandler c)
	{
		db=c;
	}
	
	public PrimaryController()
	{		
		db = new codeHandler();
    	//user=new User();
    	
    	//personRepo = new PersonRepository(db);   	
    	//authHandler = new AuthenticationHandler (personRepo);  	
    	//authController = new AuthenticationController (authHandler);
    	
    	
		//userHomeController = new UserHomePageController();
	}
	
	public void establishConnection()
	{
		db.establishConnection();
		this.connection=db.connection;
		auth=new authentication(this.connection);
		userDB=new userDB(this.connection);
		inspectorDB=new inspectorDB(this.connection);
		adminDB=new adminDB(this.connection);
		
		
		this.Userload=new userload(this.connection);
		this.Inspectorload=new inspectorload(this.connection);
		this.adminload=new adminload(this.connection);
		
		
		
	}
	
	public void closeConnection()
	{
		//db.endConnection();
	}
	
	public int Bidid_Extractor(String input) {
        // Regular expression to match "Bid ID: <number>"
        String regex = "Bid ID: (\\d+)";  // (\\d+) will capture the digits following "Bid ID: "
        
        // Compile the regular expression
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        
        // Check if the pattern matches
        if (matcher.find()) {
            // Extract the Bid ID as a string
            String bidIdStr = matcher.group(1);
            
            // Convert the extracted string to an integer
            int bidId = Integer.parseInt(bidIdStr);
            System.out.println("Bid ID: " + bidId);
            
            // Return the integer value
            return bidId;
        } else {
            System.out.println("Bid ID not found");
            
            // Return a default value in case of no match, for example, -1
            return -1;
        }
    }
	
	public void AdminLoader()
	{
		this.inspectorDB.setItemSold();
		Admin temp=this.adminload.getUserDetailsByID(adminID);
		this.admin=temp;
	}
	
	public void UserLoader()
	{
		this.inspectorDB.setItemSold();
		User temp=this.Userload.getUserDetailsByID(userID);
		this.user=temp;
		
	
		int bidderid=this.Userload.getBidderIDByUserID(userID);
		int sellerid=this.Userload.getSellerIDByUserID(userID);
		
		if(bidderid!=-1)
		{
			this.user.setBidder(bidderid);
			this.user.bidder.bid_placed=this.Userload.getAllBidsByBidderID(bidderid);
		}
		else
		{
			this.user.bidder=null;
		}
		if(sellerid!=-1)
		{
			this.user.setSeller(sellerid);
			this.user.seller.items=this.Userload.getItemsBySellerID(sellerid);
		}
		else
		{
			this.user.seller=null;
			
		}
		
		
	}
	
	public void InspectorLoader()
	{
		this.inspectorDB.setItemSold();
		Inspector temp=this.Inspectorload.getUserDetailsByID(inspectorID);
		this.inspector=temp;
	}
	
	
	public static int extractItemID(String itemString) {
	    // Split the string using the " - " delimiter
	    String[] parts = itemString.split(" - ");
	    
	    // The first part is the itemID, convert it to an integer
	    try {
	        return Integer.parseInt(parts[0].trim());
	    } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
	        e.printStackTrace();
	        throw new IllegalArgumentException("Invalid input string format: " + itemString);
	    }
	}
	
	public static int extractID(String input) {
        try {
            // Split the string by commas and find the part that starts with "ID:"
            String[] parts = input.split(",");
            for (String part : parts) {
                part = part.trim(); // Remove leading/trailing spaces
                if (part.startsWith("ID:")) {
                    // Extract the number after "ID:"
                    return Integer.parseInt(part.substring(3).trim());
                }
            }
        } catch (NumberFormatException e) {
            System.err.println("Invalid number format in input: " + input);
        }

        // Return -1 if no valid ID is found
        return -1;
    }

}