package controller;

import codingLayer.PrimaryController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class chooseRole {

	@FXML
	private PrimaryController primaryController;
	
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}

	@FXML
	void adminClicked(ActionEvent event) {
	    loadLoginScene("Admin", event);
	}

	@FXML
	void userClicked(ActionEvent event) {
	    loadLoginScene("User", event);
	}

	@FXML
	void inspectorClicked(ActionEvent event) {
	    loadLoginScene("Inspector", event);
	}

	private void loadLoginScene(String role, ActionEvent event) {
	    try {
	        // Load the LoginSignup.fxml file
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/LoginSignup.fxml"));
	        Parent scene2Root = loader.load();
	        
	        

	        // Get the LoginSignupController and set the role
	        LoginSignup controller = loader.getController();
	        controller.setRole(role);
	        controller.setPrimaryController(primaryController);

	        // Get the current stage and set the new scene
	        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	        Scene scene = new Scene(scene2Root);
	        stage.setScene(scene);
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

    
    @FXML
    void backClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
         
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/chooseRole.fxml"));
            Parent scene2Root = previousScene.load();
        	
            chooseRole controller = previousScene.getController();
            controller.setPrimaryController(primaryController);

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
