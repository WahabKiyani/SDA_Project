package controller;

import java.io.IOException;
import java.util.List;

import codingLayer.PrimaryController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import model.AuctionReport;

public class itemReports
{
	@FXML
	private PrimaryController primaryController;
	
	  @FXML
	    private ListView<String> textField;
	  
	  public String role;
	
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}
	
	
	List<AuctionReport> auctionReport;
	
	
	
	@FXML
    void backClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
            
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/Sellerbuyerdashboard.fxml"));
            Parent scene2Root = previousScene.load();
        	
            Sellerbuyerdashboard controller = previousScene.getController();
            controller.setPrimaryController(primaryController);

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	public void getReport() {
		  List<AuctionReport> auctionReport;
	    // Check if the user is a bidder
	    if (this.primaryController.user.bidder != null && "buyer".equals(role)) {
	    	
	    	

	   
	         auctionReport = this.primaryController.userDB.getAuctionReportsByBidderId(this.primaryController.user.bidder.bidderID);

	        // Clear the ListView before populating
	        textField.getItems().clear();

	        if (auctionReport != null && !auctionReport.isEmpty()) {
	            // Add auction report details to the ListView
	            for (AuctionReport report : auctionReport) {
	                String reportDetails = "Item ID: " + report.getItem_id() +
	                                       ", Price: " + report.getPrice() +
	                                       ", Description: " + report.getDescrption() +
	                                       ", SellerId: " + report.getSeller_id() +
	                                       ", BidderId: " + report.getBidder_id() +
	                                       ", Date: " + report.getReportDate();
	                textField.getItems().add(reportDetails);
	            }
	        } else {
	            // No reports found for the bidder
	            textField.getItems().add("You have not bought any items.");
	        }
	    }
	    
	    
	 
	    
	    
	    
	    
	    
	    
	    
	    
	    
	     if (this.primaryController.user.seller != null && "seller".equals(role)) {
	    	
	    	

	 	   
	         auctionReport = this.primaryController.userDB.getAuctionReportsBysellerId(this.primaryController.user.seller.getSellerID());

	        // Clear the ListView before populating
	        textField.getItems().clear();

	        if (auctionReport != null && !auctionReport.isEmpty()) {
	            // Add auction report details to the ListView
	            for (AuctionReport report : auctionReport) {
	                String reportDetails = "Item ID: " + report.getItem_id() +
	                                       ", Price: " + report.getPrice() +
	                                       ", Description: " + report.getDescrption() +
	                                       ", SellerId: " + report.getSeller_id() +
	                                       ", BidderId: " + report.getBidder_id() +
	                                       ", Date: " + report.getReportDate();
	                textField.getItems().add(reportDetails);
	            }
	        } else {
	            // No reports found for the bidder
	            textField.getItems().add("You have not Sold any items.");
	        }
	    } 
	}
	
	
	
	
	
	
	
	
	@FXML
	void initialize() {
	    // Add a click listener to the ListView
		textField.setOnMouseClicked(event -> {
	        if (event.getClickCount() == 2) { // Detect double-clicks
	            String selectedItem = textField.getSelectionModel().getSelectedItem(); // Replace String with your object
	            if (selectedItem != null) {
	            	 openItemDetailsPage(selectedItem, new ActionEvent(event.getSource(), event.getTarget()));
	            }
	        }
	    });
	}

	
	private void openItemDetailsPage(String selectedItem, ActionEvent event) {
	    try {
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/detailReport.fxml"));
	        Parent root = loader.load();
	        
	        System.out.println(selectedItem);

	        int bidID=this.primaryController.Bidid_Extractor(selectedItem);
        	
	        detailReport controller = loader.getController();
            controller.setPrimaryController(primaryController);
            controller.parseAndPrintReportDetails(selectedItem);
         
	       
	     
	        // Get the current stage from the event and set the new scene
	        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	        stage.setScene(new Scene(root));
	        stage.setTitle("Item Details");
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}

}
