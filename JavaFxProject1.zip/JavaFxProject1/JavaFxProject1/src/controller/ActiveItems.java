package controller;

import java.io.IOException;
import java.util.List;

import codingLayer.PrimaryController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import model.Item;
public class ActiveItems{
	
	@FXML
	private PrimaryController primaryController;
	
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}
	
	@FXML
    private ListView<String> listView; // Link this to your FXML ListView

    private List<Item> itemList; // This should hold your list of items
	@FXML
    void backClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
       
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/SellDashboard.fxml"));
            Parent scene2Root = previousScene.load();
        	
            SellDashboard controller = previousScene.getController();
            controller.setPrimaryController(primaryController);

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	public void setItemList(List<Item> items) {
	    this.itemList = items;

	    if (itemList == null || itemList.isEmpty()) {
	        listView.setItems(FXCollections.observableArrayList("No items available."));
	    } else {
	        populateListView();
	    }
	}


	private void populateListView() {
	    if (itemList == null || itemList.isEmpty()) {
	        listView.setItems(FXCollections.observableArrayList("No items available."));
	        return;
	    }

	    ObservableList<String> itemDetails = FXCollections.observableArrayList();
	    for (Item item : itemList) {
	        // Check if the item's status is "Active"
	        if ("Available".equalsIgnoreCase(item.getStatus())) {
	            // Create a display string for each active item
	            String details = String.format(
	                "ID: %d | Name: %s | Category: %s | Starting Price: %.2f | Current Price: %.2f | Status: %s",
	                item.getItemID(),
	                item.getItemName(),
	                item.getCategory(),
	                item.getStartingPrice(),
	                item.getCurrentPrice(),
	                item.getStatus()
	            );
	            itemDetails.add(details);
	        }
	    }
	    

	    if (itemDetails.isEmpty()) {
	        listView.setItems(FXCollections.observableArrayList("No active items available."));
	    } else {
	        listView.setItems(itemDetails);
	    }
	}
	
	@FXML
	void initialize() {
	    // Add a click listener to the ListView
	    listView.setOnMouseClicked(event -> {
	        if (event.getClickCount() == 2) { // Detect double-clicks
	            String selectedItem = listView.getSelectionModel().getSelectedItem(); // Retrieve the selected Item object
	            if (selectedItem != null) {
	                openItemDetailsPage(selectedItem, new ActionEvent(event.getSource(), event.getTarget()));
	            }
	        }
	    });
	}


	private void openItemDetailsPage(String selectedItem, ActionEvent event) {
	    try {
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/viewActiveItems.fxml"));
	        Parent root = loader.load();
	        
	        System.out.println(selectedItem);

	      //  int bidID=this.primaryController.Bidid_Extractor(selectedItem);
        	
	        viewActiveItems controller = loader.getController();
            controller.setPrimaryController(primaryController);
            controller.displayItemDetails(selectedItem);
           // controller.setbidID(bidID);
	       // controller.loadItemDetails(bidID);
	       
	     
	        // Get the current stage from the event and set the new scene
	        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	        stage.setScene(new Scene(root));
	        stage.setTitle("Item Details");
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	


}