package controller;

import codingLayer.PrimaryController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;

public class ContactUs {

    private String previousScenePath; // Store the previous scene's FXML file path
    private String role;

    // Method to set the previous scene's FXML file path
    public void setPreviousScene(String previousScenePath) {
        this.previousScenePath = previousScenePath;
    }
    
    @FXML
	private PrimaryController primaryController;
	
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}

    // Handle Back button click
    public void backClicked(ActionEvent event) {
        if (previousScenePath != null) {
            try {
                // Load the previous FXML file
                FXMLLoader previousScene = new FXMLLoader(getClass().getResource(previousScenePath));
                Parent scene2Root = previousScene.load();

                // Check if the previous scene is "Signup.fxml" and pass the role if necessary
                if (previousScenePath.equals("/view/Signup.fxml")) { // Use .equals() for string comparison
                    Signup controller = previousScene.getController();
                    controller.setRole(role);
                    controller.setPrimaryController(primaryController);
                }
                
                else if (previousScenePath.equals("/view/Login.fxml")) { // Use .equals() for string comparison
                    Login controller = previousScene.getController();
                    controller.setRole(role);
                    controller.setPrimaryController(primaryController);
                }
                
                else if (previousScenePath.equals("/view/Sellerbuyerdashboard.fxml")) { // Use .equals() for string comparison
                	Sellerbuyerdashboard controller = previousScene.getController();
                   
                    controller.setPrimaryController(primaryController);
                }
                
                else if (previousScenePath.equals("/view/adminDashboard.fxml")) { // Use .equals() for string comparison
                	adminDashboard controller = previousScene.getController();
                   
                    controller.setPrimaryController(primaryController);
                }
                
                else if (previousScenePath.equals("/view/inspectorDashboard.fxml")) { // Use .equals() for string comparison
                	inspectorDashboard controller = previousScene.getController();
               
                    controller.setPrimaryController(primaryController);
                }

                // Get the current stage and set the new scene
                Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                Scene scene = new Scene(scene2Root);
                stage.setScene(scene);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            System.err.println("Previous scene path is not set.");
        }
    }

    
    public void setRole(String role) {
        this.role = role;
        System.out.println("Role from ContactUs: " + role); // Debugging
    }
}
