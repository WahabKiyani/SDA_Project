package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import codingLayer.PrimaryController;
import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import model.Inspector;
import model.User;



public class inspectorDashboard
{
	
	@FXML
	private PrimaryController primaryController;
	
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}
	  @FXML
	    void pendinginspectionclicked(ActionEvent event) {
		  
		  try {
	            // Load the LoginSignup.fxml file
	     
	            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/pendingInspections.fxml"));
	            Parent scene2Root = previousScene.load();
	        	
	            pendingInspections controller = previousScene.getController();
	            controller.setPrimaryController(primaryController);
	            controller.displayPendingItems();
	            

	            // Get the current stage and set the new scene
	            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	            Scene scene = new Scene(scene2Root);
	            stage.setScene(scene);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	  
	  
	  
	  @FXML
	    void completedinspectionclicked(ActionEvent event) {
		  
		  try {
	            // Load the LoginSignup.fxml file
	           
	            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/completedInspections.fxml"));
	            Parent scene2Root = previousScene.load();
	        	
	            completedInspections controller = previousScene.getController();
	            controller.setPrimaryController(primaryController);
	            controller.displayPendingItems();
	            
	            
	            // Get the current stage and set the new scene
	            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	            Scene scene = new Scene(scene2Root);
	            stage.setScene(scene);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	  
	  
	  
	  @FXML
	    void bookedinspectionclicked(ActionEvent event) {
		  
		  try {
	            // Load the LoginSignup.fxml file
	         
	            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/bookedInspections.fxml"));
	            Parent scene2Root = previousScene.load();
	        	
	            bookedInspections controller = previousScene.getController();
	            controller.setPrimaryController(primaryController);
	            controller.displayPendingItems();


	            // Get the current stage and set the new scene
	            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	            Scene scene = new Scene(scene2Root);
	            stage.setScene(scene);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	  
	  
	  
	  @FXML
	    void contactusclicked(ActionEvent event) {
		    
		  try {
		        // Load the ContactUs.fxml file using FXMLLoader
		        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/ContactUs.fxml"));
		        Parent contactUsRoot = loader.load();

		        // Get the ContactUs controller and set the previous scene's path
		        ContactUs controller = loader.getController();
		        controller.setPreviousScene("/view/inspectorDashboard.fxml");
		        controller.setPrimaryController(primaryController);
		        

		        // Set the new scene
		        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
		        Scene scene = new Scene(contactUsRoot);
		        stage.setScene(scene);
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
	    }
	  
	  
	  @FXML
	    void inspectorinfoclicked(ActionEvent event) {
		   
		  try {
			  
			  
		        // Load the ContactUs.fxml file using FXMLLoader
		        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/yourInfo.fxml"));
		        Parent contactUsRoot = loader.load();

		        // Get the ContactUs controller and set the previous scene's path
		        yourInfo controller = loader.getController();
		        controller.setPreviousScene("/view/inspectorDashboard.fxml");
		        controller.setPrimaryController(primaryController);
		        
		       
		        Inspector user=this.primaryController.inspector;
		        controller.role="Inspector";
		        String date=this.primaryController.auth.getRegistrationDateInspector(user.getInspectorID());
		        controller.populateFields(user.getName(), user.getEmail(), user.getPhoneNumber(), date, user.getPassword());
		       

		        // Set the new scene
		        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
		        Scene scene = new Scene(contactUsRoot);
		        stage.setScene(scene);
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
	    }
	  
};