package controller;

import java.sql.SQLException;

import codingLayer.PrimaryController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.Bidder;
import model.Item;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class bidItem {

    private String previousScenePath; // Store the previous scene's FXML file path
    private String role;
    private int BidId;
    private Item item;

    // Method to set the previous scene's FXML file path
    public void setPreviousScene(String previousScenePath) {
        this.previousScenePath = previousScenePath;
    }
    public void setbidID(int n) {
        this.BidId=n;
    }
    
    @FXML
	private PrimaryController primaryController;
	
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}
	
	
	@FXML private TextField itemNameField;
    @FXML private TextField itemCategoryField;
    @FXML private TextField itemDescriptionField;
    @FXML private TextField amountField;
    
    private int itemID;

    // Method to initialize and load item details
    public void loadItemDetails(int bidID) {
     //   this.itemID = itemID;
        
        // Fetch item details from database
        item = this.primaryController.userDB.getItemDetails(bidID);
        if (item != null) {
            itemNameField.setText(item.getItemName());
            itemCategoryField.setText(item.getCategory());
            itemDescriptionField.setText(item.getDescription());
        }
        else
        {
        	System.out.println("Items Null!");
        }
    }
    
    public void loadItemDetailsthroughItem(int itemID) {
        //   this.itemID = itemID;
           
           // Fetch item details from database
           item = this.primaryController.userDB.getItem(itemID);
           if (item != null) {
               itemNameField.setText(item.getItemName());
               itemCategoryField.setText(item.getCategory());
               itemDescriptionField.setText(item.getDescription());
           }
           else
           {
           	System.out.println("Items Null!");
           }
       }
    

	    private void showAlert(String title, String message) {
	        Alert alert = new Alert(AlertType.ERROR);
	        alert.setTitle(title);
	        alert.setHeaderText(null);
	        alert.setContentText(message);
	        alert.showAndWait();
	    }

    // Handle Back button click
	@FXML
    public void backClicked(ActionEvent event) {
        if (previousScenePath != null) {
            try {
                // Load the previous FXML file
                FXMLLoader previousScene = new FXMLLoader(getClass().getResource(previousScenePath));
                Parent scene2Root = previousScene.load();

                // Check if the previous scene is "Signup.fxml" and pass the role if necessary
                if (previousScenePath.equals("/view/ActiveBids.fxml")) { // Use .equals() for string comparison
                	ActiveBids controller = previousScene.getController();
                  
                    controller.setPrimaryController(primaryController);
                    int userid=this.primaryController.user.getUserID();
                	controller.bidListView.setItems(this.primaryController.userDB.displayUserBids(userid));
                	System.out.println(controller.bidListView.getItems());
                    
                }
                
                else if (previousScenePath.equals("/view/carAuction.fxml")) { // Use .equals() for string comparison
                	carAuction controller = previousScene.getController();
                    
                    controller.setPrimaryController(primaryController);
                
               //     controller.setPreviousScene("/view/carAuction.fxml");
                   // controller.setbidID(bidID);
                    controller.filterItemsByCategory("Car");
                }
                
                else if (previousScenePath.equals("/view/artAuction.fxml")) { // Use .equals() for string comparison
                	artAuction controller = previousScene.getController();
                   
                    controller.setPrimaryController(primaryController);
                    controller.filterItemsByCategory("Art");
                }
                
                else if (previousScenePath.equals("/view/electronicAuction.fxml")) { // Use .equals() for string comparison
                	electronicAuction controller = previousScene.getController();
                   
                    controller.setPrimaryController(primaryController);
                    controller.filterItemsByCategory("Electronic");
                }
                
                else if (previousScenePath.equals("/view/antiqueAuction.fxml")) { // Use .equals() for string comparison
                	antiqueAuction controller = previousScene.getController();
               
                    controller.setPrimaryController(primaryController);
                    controller.filterItemsByCategory("Antique");
                }

                // Get the current stage and set the new scene
                Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                Scene scene = new Scene(scene2Root);
                stage.setScene(scene);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            System.err.println("Previous scene path is not set.");
        }
    }

    	@FXML
        public void placebidClicked(ActionEvent event) throws SQLException {
            try {
                float enteredAmount = Float.parseFloat(amountField.getText());

                System.out.println(item.getItemID());
                System.out.println(enteredAmount);
                // Validate the entered amount
                if (!this.primaryController.userDB.isValidBid(item.getItemID(), enteredAmount)) {
                    showAlert("Invalid bid", "Your bid must be higher than the current price and starting price.");
                    return;
                }

                //int userid=this.primaryController.
               // if(this.primaryController.userDB.getBidderIDByUserID())
                // Get current bidder ID
                //int bidderID = this.primaryController.user.getUserID();
               // this.primaryController.userDB.addToBidder(bidderID);
                // Place the bid
                int bidderid=this.primaryController.userDB.getBidderIDByUserID2(this.primaryController.userID);
                
                if(this.primaryController.user.bidder==null)
                {
                	this.primaryController.user.bidder=new Bidder(bidderid);
                }
                
                
                if (this.primaryController.userDB.insertBid(bidderid, item.getItemID(), enteredAmount)!=-1) {
                    showAlert("Bid placed", "Your bid has been placed successfully.");
                    this.primaryController.userDB.updateCurrentPrice(item.getItemID(), enteredAmount);
                    this.primaryController.UserLoader();
                    this.primaryController.auth.insertLog("Bid placed",this.primaryController.user.getEmail() );
                } else {
                    showAlert("Error", "An error occurred while placing the bid.");
               }

            } catch (NumberFormatException e) {
                showAlert("Invalid amount", "Please enter a valid bid amount.");
            }
        }
    

    
    public void setRole(String role) {
        this.role = role;
        System.out.println("Role from ContactUs: " + role); // Debugging
    }
    
}
