package controller;

import codingLayer.PrimaryController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class HotAuctions{
	
	@FXML
	private PrimaryController primaryController;
	
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}
	@FXML
    void homeClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
         
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/Sellerbuyerdashboard.fxml"));
            Parent scene2Root = previousScene.load();
        	
            Sellerbuyerdashboard controller = previousScene.getController();
            controller.setPrimaryController(primaryController);

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}