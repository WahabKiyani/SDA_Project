package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import java.io.IOException;

import codingLayer.PrimaryController;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;



public class bookedInspections
{
	
	@FXML
	private PrimaryController primaryController;
	
	
	
	  @FXML
	    private ListView<String> textField;



	    @FXML
	    private TextField priceField;
	    
	    @FXML
	    private TextField decField;
	
	    
	    
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}
	  @FXML
	    void inspectorhomeclicked(ActionEvent event) {
		  
		  try {
	            // Load the LoginSignup.fxml file
	          
	            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/inspectorDashboard.fxml"));
	            Parent scene2Root = previousScene.load();
	        	
	            inspectorDashboard controller = previousScene.getController();
	            controller.setPrimaryController(primaryController);


	            // Get the current stage and set the new scene
	            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	            Scene scene = new Scene(scene2Root);
	            stage.setScene(scene);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	  
	  
	  public void displayPendingItems() {
		    ObservableList<String> pendingItems = this.primaryController.inspectorDB.getInprogressItems();
		    textField.setItems(pendingItems);
		}
	  
	  @FXML
	    private void approved() throws IOException {
	        String selectedItem = textField.getSelectionModel().getSelectedItem();
	       // String selectedDate = datePicker.getValue() != null ? datePicker.getValue().toString() : null;
	        String price = priceField.getText();
	        String des=decField.getText();

	        if (selectedItem == null) {
	            showAlert("Error", "No item selected. Please select an item to book.");
	            return;
	        }

	        if (price.isEmpty() || des.isEmpty()) {
	            showAlert("Error", "Please enter a valid Price and Description.");
	            return;
	        }

	        // If all fields are valid
	        showAlert("Success", "Inspection Successful for:\n" + selectedItem + "\nPrice: " + price + "\nDes: " + des);
	        int id=this.primaryController.extractID(selectedItem);
	        int p= Integer.parseInt(price);
	        this.primaryController.inspectorDB.setItemStatusToActive(id,p);
	        this.primaryController.auth.insertLog("Item status to active", this.primaryController.inspector.getEmail());
	        this.displayPendingItems();
	        priceField.setText(null);
	        decField.setText(null);
	        

        

	        
	    }
	  
	  @FXML
	    private void disapproved() {
		 String selectedItem = textField.getSelectionModel().getSelectedItem();
	       // String selectedDate = datePicker.getValue() != null ? datePicker.getValue().toString() : null;
	    //    String price = priceField.getText();
	   //     String des=decField.getText();

	        if (selectedItem == null) {
	            showAlert("Error", "No item selected. Please select an item to inspect.");
	            return;
	        }

	    
	        // If all fields are valid
	        showAlert("Success", "Inspection Successful for:\n" + selectedItem);
	        int id=this.primaryController.extractID(selectedItem);
	        this.primaryController.inspectorDB.setItemStatusToCancel(id);
	        this.primaryController.auth.insertLog("Item status to Cancel", this.primaryController.inspector.getEmail());
	        
	    }

	    // Utility method to display alerts
	    private void showAlert(String title, String message) {
	        Alert alert = new Alert(Alert.AlertType.INFORMATION, message, ButtonType.OK);
	        alert.setTitle(title);
	        alert.setHeaderText(null);
	        alert.showAndWait();
	    }
	  
	  
	
	  
	  
	  
	  }
  
	  
	  