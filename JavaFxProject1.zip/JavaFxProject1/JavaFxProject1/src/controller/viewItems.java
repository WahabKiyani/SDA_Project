package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import codingLayer.PrimaryController;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.Stage;



public class viewItems
{
	
	@FXML
	private PrimaryController primaryController;
	
	  @FXML
	    private ListView<String> textField;
	
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}
	  @FXML
	    void adminhomeclicked(ActionEvent event) {
		  
		  try {
	            // Load the LoginSignup.fxml file
	            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/adminDashboard.fxml"));
	            Parent scene2Root = previousScene.load();
	        	
	            adminDashboard controller = previousScene.getController();
	            controller.setPrimaryController(primaryController);


	            // Get the current stage and set the new scene
	            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	            Scene scene = new Scene(scene2Root);
	            stage.setScene(scene);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	  
	  
	  
	  public void displayPendingItems() {
		    ObservableList<String> pendingItems = this.primaryController.adminDB.getitemmsList();
		    textField.setItems(pendingItems);
		}
	  
	@FXML
	public void detailsclicked(ActionEvent event) {
      // Get the selected user from the ListView
      String selectedItem = textField.getSelectionModel().getSelectedItem();

      if (selectedItem != null) {
        
        
          showUserDetailsPopup(selectedItem);
      }
  }

	
	private void showUserDetailsPopup(String userDetails) {
      // Create an Alert to display the user details
      Alert alert = new Alert(AlertType.INFORMATION);
      alert.setTitle("User Details");
      alert.setHeaderText("Details of the selected Item");
      alert.setContentText(userDetails);

      // Show the alert and wait for user to close it
      alert.showAndWait();
  }
	  
	  
	  
	  
	  }
  
	  
	  