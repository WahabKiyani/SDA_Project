package controller;

import codingLayer.PrimaryController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Admin;
import model.Inspector;
import model.User;

public class Login {
	
	@FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;
    
	private String role;
	@FXML
    void backClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
          
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/LoginSignup.fxml"));
            Parent scene2Root = previousScene.load();
        	
            LoginSignup controller = previousScene.getController();
            controller.setPrimaryController(primaryController);

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	@FXML
	private PrimaryController primaryController;
	
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}
	
	@FXML
    void homeClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
            
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/chooseRole.fxml"));
            Parent scene2Root = previousScene.load();
        	
            chooseRole controller = previousScene.getController();
            controller.setPrimaryController(primaryController);

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	
	@FXML
	void loginClicked(ActionEvent event) {
	    try {
	        // Get email and password from the fields
	        String email = emailField.getText();
	        String password = passwordField.getText();
	        Parent contactUsRoot = null;

	        if (role.equals("User")) {
	            int isAuthenticated = primaryController.auth.authenticateUser(email, password);

	            if (isAuthenticated!=-1) {
	            	this.primaryController.user=new User();
	            	this.primaryController.userID=isAuthenticated;
	            	this.primaryController.UserLoader();
	            	
	                // If authenticated, load the SellerBuyerDashboard FXML
	                FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Sellerbuyerdashboard.fxml"));
	                contactUsRoot = loader.load();  // No need to cast to AnchorPane
	                Sellerbuyerdashboard controller = loader.getController();
	                controller.setPrimaryController(primaryController);

	                // Switch to the new scene (dashboard)
	                Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	                Scene scene = new Scene(contactUsRoot);
	                stage.setScene(scene);
	            } else {
	                // Show authentication failure alert and keep user on login screen
	                Alert alert = new Alert(Alert.AlertType.ERROR);
	                alert.setTitle("Authentication Failed");
	                alert.setHeaderText("Login Error");
	                alert.setContentText("The username or password you entered is incorrect. Please try again.");
	                alert.showAndWait();
	            }
	        } else if (role.equals("Admin")) {
	        	
	        	int isAuthenticated = primaryController.auth.authenticateAdmin(email, password);

	            if (isAuthenticated!=-1) {
	            	
	            	this.primaryController.admin=new Admin();
	            	this.primaryController.adminID=isAuthenticated;
	            	this.primaryController.AdminLoader();
	            	
	            	
	            	//this.primaryController.admin=new Admin(isAuthenticated,  "",  email,  password);
	                // If authenticated, load the SellerBuyerDashboard FXML
	                FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/adminDashboard.fxml"));
	                contactUsRoot = loader.load();  // No need to cast to AnchorPane
	                adminDashboard controller = loader.getController();
	                controller.setPrimaryController(primaryController);

	                // Switch to the new scene (dashboard)
	                Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	                Scene scene = new Scene(contactUsRoot);
	                stage.setScene(scene);
	            } else {
	                // Show authentication failure alert and keep user on login screen
	                Alert alert = new Alert(Alert.AlertType.ERROR);
	                alert.setTitle("Authentication Failed");
	                alert.setHeaderText("Login Error");
	                alert.setContentText("The username or password you entered is incorrect. Please try again.");
	                alert.showAndWait();
	            }
	            
	        } else if (role.equals("Inspector")) {
	        	
	        	int isAuthenticated = primaryController.auth.authenticateInspector(email, password);

	            if (isAuthenticated!=-1) {
	            	
	            	this.primaryController.inspector=new Inspector();
	            	this.primaryController.inspectorID=isAuthenticated;
	            	this.primaryController.InspectorLoader();
	            	
	            	//this.primaryController.inspector=new Inspector(isAuthenticated,  "",  email,  password);
	                // If authenticated, load the SellerBuyerDashboard FXML
	                FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/inspectorDashboard.fxml"));
	                contactUsRoot = loader.load();  // No need to cast to AnchorPane
	                inspectorDashboard controller = loader.getController();
	                controller.setPrimaryController(primaryController);

	                // Switch to the new scene (dashboard)
	                Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	                Scene scene = new Scene(contactUsRoot);
	                stage.setScene(scene);
	            } else {
	                // Show authentication failure alert and keep user on login screen
	                Alert alert = new Alert(Alert.AlertType.ERROR);
	                alert.setTitle("Authentication Failed");
	                alert.setHeaderText("Login Error");
	                alert.setContentText("The username or password you entered is incorrect. Please try again.");
	                alert.showAndWait();
	            }
	            
	        } else {
	            // Handle unknown roles (optional)
	            Alert alert = new Alert(Alert.AlertType.ERROR);
	            alert.setTitle("Unknown Role");
	            alert.setHeaderText("Role Error");
	            alert.setContentText("The role is not recognized. Please contact support.");
	            alert.showAndWait();
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}


	
	

    // Get the ContactUs controller and set the previous scene's path
    
	
	
	@FXML
    void contactClicked(ActionEvent event) {
		try {
	        // Load the ContactUs.fxml file using FXMLLoader
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/ContactUs.fxml"));
	        Parent contactUsRoot = loader.load();

	        // Get the ContactUs controller and set the previous scene's path
	        ContactUs controller = loader.getController();
	        controller.setPreviousScene("/view/Login.fxml");
	        controller.setRole(role);
	        controller.setPrimaryController(primaryController);

	        // Set the new scene
	        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	        Scene scene = new Scene(contactUsRoot);
	        stage.setScene(scene);
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
    }
	
	@FXML
    void registerClicked(ActionEvent event) {
		try {
	        // Load the LoginSignup.fxml file
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Signup.fxml"));
	        Parent scene2Root = loader.load();

	        // Get the LoginSignupController and set the role
	        Signup controller = loader.getController();
	        controller.setRole(role);
	        controller.setPrimaryController(primaryController);

	        // Get the current stage and set the new scene
	        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	        Scene scene = new Scene(scene2Root);
	        stage.setScene(scene);
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
    }
	
	public void setRole(String role) {
        this.role = role;
        System.out.println("Role from Login: " + role); // Debugging
    }

}