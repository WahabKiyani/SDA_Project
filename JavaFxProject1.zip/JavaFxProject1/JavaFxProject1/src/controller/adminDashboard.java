package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import codingLayer.PrimaryController;
import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import model.Admin;



public class adminDashboard
{
	
	@FXML
	private PrimaryController primaryController;
	
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}
	  @FXML
	    void viewmembersclicked(ActionEvent event) {
		  
		  try {
	            // Load the LoginSignup.fxml file
	         
	            
	            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/viewMembers.fxml"));
	            Parent scene2Root = previousScene.load();
	        	
	            viewMembers controller = previousScene.getController();
	            controller.setPrimaryController(primaryController);
	            controller.displayPendingItems();

	            // Get the current stage and set the new scene
	            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	            Scene scene = new Scene(scene2Root);
	            stage.setScene(scene);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	  
	  
	
	  @FXML
	    void viewinspectorsclicked(ActionEvent event) {
		  
		  try {
	            // Load the LoginSignup.fxml file

	            
	            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/viewInspectors.fxml"));
	            Parent scene2Root = previousScene.load();
	        	
	            viewInspectors controller = previousScene.getController();
	            controller.setPrimaryController(primaryController);
	            controller.displayPendingItems();

	            // Get the current stage and set the new scene
	            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	            Scene scene = new Scene(scene2Root);
	            stage.setScene(scene);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	  
	  @FXML
	    void viewlogsclicked(ActionEvent event) {
		  
		  try {
	            // Load the LoginSignup.fxml file
	         
	            
	            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/viewLogs.fxml"));
	            Parent scene2Root = previousScene.load();
	        	
	            viewLogs controller = previousScene.getController();
	            controller.setPrimaryController(primaryController);
	            controller.displayPendingItems();
	            
	            
	            // Get the current stage and set the new scene
	            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	            Scene scene = new Scene(scene2Root);
	            stage.setScene(scene);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	  
	  @FXML
	    void viewitemsclicked(ActionEvent event) {
		  
		  try {
	            // Load the LoginSignup.fxml file
	            
	            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/viewItems.fxml"));
	            Parent scene2Root = previousScene.load();
	        	
	            viewItems controller = previousScene.getController();
	            controller.setPrimaryController(primaryController);
	            controller.displayPendingItems();

	            // Get the current stage and set the new scene
	            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	            Scene scene = new Scene(scene2Root);
	            stage.setScene(scene);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	  
	  
	  @FXML
	    void admininfoclicked(ActionEvent event) {
		  
		  
		  try {
		        // Load the ContactUs.fxml file using FXMLLoader
		        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/yourInfo.fxml"));
		        Parent contactUsRoot = loader.load();

		        // Get the ContactUs controller and set the previous scene's path
		        yourInfo controller = loader.getController();
		        controller.setPreviousScene("/view/adminDashboard.fxml");
		        controller.setPrimaryController(primaryController);
		        
		        
		        Admin user=this.primaryController.admin;
		        controller.role="Admin";
		        String date=this.primaryController.auth.getRegistrationDateAdmin(user.getAdminID());
		        controller.populateFields(user.getName(), user.getEmail(), user.getPhoneNumber(), date, user.getPassword());
		       
		        
		        
		        // Set the new scene
		        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
		        Scene scene = new Scene(contactUsRoot);
		        stage.setScene(scene);
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
	    }
	  
	
	  @FXML
	    void contactusclicked(ActionEvent event) {
		  
		  try {
		        // Load the ContactUs.fxml file using FXMLLoader
		        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/ContactUs.fxml"));
		        Parent contactUsRoot = loader.load();

		        // Get the ContactUs controller and set the previous scene's path
		        ContactUs controller = loader.getController();
		        controller.setPreviousScene("/view/adminDashboard.fxml");
		        controller.setPrimaryController(primaryController);
		        

		        // Set the new scene
		        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
		        Scene scene = new Scene(contactUsRoot);
		        stage.setScene(scene);
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
	    }
	  
	  
	  }
  
	  
	  