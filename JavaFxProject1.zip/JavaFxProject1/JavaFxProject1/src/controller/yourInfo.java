package controller;



import codingLayer.PrimaryController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class yourInfo {

    private String previousScenePath; // Store the previous scene's FXML file path
    
    @FXML
	private PrimaryController primaryController;
	
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}
	

    @FXML
    private TextField nameField;

    @FXML
    private TextField phoneField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField passField;

    @FXML
    private TextField regDateField;
    
    public String role;

    // Method to populate fields with user information
    public void populateFields(String name, String email, String phone, String regDate, String password) {
        nameField.setText(name);
        phoneField.setText(phone);
        emailField.setText(email);
        regDateField.setText(regDate);
        passField.setText(password);
    }

    // Save button click handler
    @FXML
    private void saveClicked() {
        String newName = nameField.getText().trim();
        String newPassword = passField.getText().trim();

        // Validate inputs
        if (newName.isEmpty()) {
            showAlert("Invalid Input", "Name cannot be empty.");
            return;
        }

        if (newPassword.isEmpty()) {
            showAlert("Invalid Input", "Password cannot be empty.");
            return;
        }
        boolean success;
        if(role=="Inspector")
        {
        	success =this.primaryController.auth.saveNewInfoInspector(newName, newPassword, emailField.getText());
        }
        else if (role=="Admin")
        {
        	success =this.primaryController.auth.saveNewInfoAdmin(newName, newPassword, emailField.getText());
        }
        else
         success =this.primaryController.auth.saveNewInfo(newName, newPassword, emailField.getText());
        // Simulate saving to database
        //boolean success = this.primaryController.(newName, newPassword);

        if (success) {
            showAlert("Success", "Your information has been updated successfully!");
            if(role=="Inspector")
            {
            	this.primaryController.InspectorLoader();
            }
            else if(role=="Admin") {
            	this.primaryController.AdminLoader();
            }
            else
            this.primaryController.UserLoader();
        } else {
            showAlert("Error", "Failed to update information. Please try again.");
        }
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Method to set the previous scene's FXML file path
    public void setPreviousScene(String previousScenePath) {
        this.previousScenePath = previousScenePath;
    }

    // Handle Back button click
    public void homeClicked(ActionEvent event) {
        if (previousScenePath != null) {
            try {
                // Load the previous FXML file
                FXMLLoader previousScene = new FXMLLoader(getClass().getResource(previousScenePath));
                Parent scene2Root = previousScene.load();
                
                if(previousScenePath=="/view/Sellerbuyerdashboard.fxml")
                {
                	Sellerbuyerdashboard controller = previousScene.getController();
                	controller.setPrimaryController(primaryController);
                }
                else if(previousScenePath=="/view/adminDashboard.fxml")
                {
                	adminDashboard controller = previousScene.getController();
                	controller.setPrimaryController(primaryController);
                }
                else if(previousScenePath=="/view/inspectorDashboard.fxml")
                {
                	inspectorDashboard controller = previousScene.getController();
                	controller.setPrimaryController(primaryController);
                }

                // Get the current stage and set the new scene
                Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                Scene scene = new Scene(scene2Root);
                stage.setScene(scene);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            System.err.println("Previous scene path is not set.");
        }
    }

    @FXML
    void logoutClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
        	
        	FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/chooseRole.fxml"));
            Parent scene2Root = previousScene.load();
        	
            chooseRole controller = previousScene.getController();
            controller.setPrimaryController(primaryController);
   

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
   
}
