package controller;

import java.io.IOException;

import codingLayer.PrimaryController;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

public class artAuction{
	
	public int itemID;
	@FXML
	private PrimaryController primaryController;
	
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}
	@FXML
    void homeClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
        
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/Sellerbuyerdashboard.fxml"));
            Parent scene2Root = previousScene.load();
        	
            Sellerbuyerdashboard controller = previousScene.getController();
            controller.setPrimaryController(primaryController);

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	@FXML
    private ListView<String> textField;

    // Method to display items based on category
    public void filterItemsByCategory(String category) {
        // Use the DatabaseUtils class to get the items
        ObservableList<String> items = this.primaryController.userDB.getItemsByCategory(category);
        System.out.println(items);
        // Update the ListView with the fetched items
        textField.setItems(items);
    }
    
    @FXML
	void initialize() {
	    // Add a click listener to the ListView
	    textField.setOnMouseClicked(event -> {
	        if (event.getClickCount() == 2) { // Detect double-clicks
	            String selectedItem = textField.getSelectionModel().getSelectedItem(); // Replace String with your object
	            if (selectedItem != null) {
	            	itemID=this.primaryController.extractItemID(selectedItem);
	            	 openItemDetailsPage(selectedItem, new ActionEvent(event.getSource(), event.getTarget()));
	            }
	        }
	    });
	}

	
	private void openItemDetailsPage(String selectedItem, ActionEvent event) {
	    try {
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/bidItem.fxml"));
	        Parent root = loader.load();
	        
	        System.out.println(selectedItem);

	        //int bidID=this.primaryController.Bidid_Extractor(selectedItem);
        	
            bidItem controller = loader.getController();
            controller.setPrimaryController(primaryController);
            controller.setPreviousScene("/view/artAuction.fxml");
           // controller.setbidID(bidID);
            System.out.println(itemID);
	        controller.loadItemDetailsthroughItem(itemID);
	       
	     
	        // Get the current stage from the event and set the new scene
	        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	        stage.setScene(new Scene(root));
	        stage.setTitle("Item Details");
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	    
	}
	
}