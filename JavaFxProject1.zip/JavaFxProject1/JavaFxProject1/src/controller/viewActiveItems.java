package controller;

import codingLayer.PrimaryController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class viewActiveItems{
	
	@FXML
	private PrimaryController primaryController;
	
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}
	
	@FXML
    private TextField nameField;

    @FXML
    private TextField categoryField;

    @FXML
    private TextField descriptionField;

    @FXML
    private TextField spriceField;

    @FXML
    private TextField hpriceField;

    public void displayItemDetails(String itemDetails) {
        // Sample input string format:
        // ID: 101 | Name: Toyota Corolla 2018 | Category: Car | Starting Price: 1500000.00 | Current Price: 1550000.00 | Status: Available
        
        // Split the string by '|'
        String[] parts = itemDetails.split("\\|");
        
        // Parse each part
        String name = parts[1].split(":")[1].trim(); // Name value
        String category = parts[2].split(":")[1].trim(); // Category value
        String startingPrice = parts[3].split(":")[1].trim(); // Starting Price value
        String currentPrice = parts[4].split(":")[1].trim(); // Current Price value

        // Assuming "Description" isn't part of the provided string, you can set it manually or add logic to extract it from somewhere.
        String description = "Description not provided."; 
        
        // Set values in TextFields
        nameField.setText(name);
        categoryField.setText(category);
        spriceField.setText(startingPrice);
        hpriceField.setText(currentPrice);
        descriptionField.setText(description);
    }
	@FXML
    void backClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
          
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/ActiveItems.fxml"));
            Parent scene2Root = previousScene.load();
        	
            ActiveItems controller = previousScene.getController();
            controller.setPrimaryController(primaryController);

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	
}