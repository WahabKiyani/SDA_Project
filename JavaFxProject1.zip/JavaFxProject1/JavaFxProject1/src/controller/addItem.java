package controller;

import codingLayer.PrimaryController;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Item;
import model.Seller;

public class addItem{
	
	@FXML
	private PrimaryController primaryController;
	
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}
	
	 @FXML
	    private TextField descField;

	    @FXML
	    private TextField priceField;

	    @FXML
	    private TextField nameField;

	    @FXML
	    private ChoiceBox<String> categoryField;

	    @FXML
	    private void initialize() {
	        // Populate the ChoiceBox with categories
	        categoryField.setItems(FXCollections.observableArrayList("Car", "Electronic", "Art", "Antique"));
	    }

	    @FXML
	    private void confirmClicked() {
	        String name = nameField.getText();
	        String category = categoryField.getValue();
	        String description = descField.getText();
	        String priceText = priceField.getText();

	        // Validate input
	        if (name == null || name.trim().isEmpty()) {
	            showAlert("Invalid Input", "Name field cannot be empty.");
	            return;
	        }

	        if (category == null) {
	            showAlert("Invalid Input", "Please select a category.");
	            return;
	        }

	        if (description == null || description.trim().isEmpty()) {
	            showAlert("Invalid Input", "Description field cannot be empty.");
	            return;
	        }

	        double price;
	        try {
	            price = Double.parseDouble(priceText);
	            if (price <= 0) {
	                showAlert("Invalid Input", "Price must be greater than 0.");
	                return;
	            }
	        } catch (NumberFormatException e) {
	            showAlert("Invalid Input", "Price must be a valid number.");
	            return;
	        }

	        // Check if item already exists
	        if (isItemExists(name, category)) {
	            showAlert("Duplicate Item", "An item with the same name and category already exists.");
	            return;
	        }

	        // If all inputs are valid and item does not exist
	        showAlert("Success", "Item Added Successfully!\n" +
	                "Name: " + name + "\n" +
	                "Category: " + category + "\n" +
	                "Description: " + description + "\n" +
	                "Price: " + price);

	        // Add the new item to the list
	      
	        	
	        addItemToList(name, category, description, price);
	    }

	    private void addItemToList(String name, String category, String description, double price) 
	    {
	    	int sellID=-1;
			if(this.primaryController.user.seller==null)
			{
				
				sellID=this.primaryController.userDB.addSeller(this.primaryController.userID);
				this.primaryController.user.seller=new Seller(sellID);
			}
			else
			{
				sellID=this.primaryController.user.seller.getSellerID();
			}
			
			if(sellID!=-1)
			{
				this.primaryController.userDB.addItem(name, category, description, price, sellID);
				this.primaryController.auth.insertLog("Item Added", this.primaryController.user.getEmail());
				this.primaryController.UserLoader();
			}
			
		}

	   
		private boolean isItemExists(String name, String category) {
	        // Assuming items is a List<Item> that contains all the current items
	    	if(this.primaryController.user.seller!=null) {
	        for (Item item : this.primaryController.user.seller.items) {
	            if (item.getItemName().equalsIgnoreCase(name) && item.getCategory().equalsIgnoreCase(category)) {
	                return true;
	            }
	        }
	    	}
	        return false;
	    }

	   


	    private void showAlert(String title, String content) {
	        Alert alert = new Alert(AlertType.INFORMATION);
	        alert.setTitle(title);
	        alert.setHeaderText(null);
	        alert.setContentText(content);
	        alert.showAndWait();
	    }
	@FXML
    void homeClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
          
            

            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/Sellerbuyerdashboard.fxml"));
            Parent scene2Root = previousScene.load();
        	
            Sellerbuyerdashboard controller = previousScene.getController();
            controller.setPrimaryController(primaryController);

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	
}