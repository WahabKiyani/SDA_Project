package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import codingLayer.PrimaryController;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;



public class pendingInspections
{
	
	@FXML
	private PrimaryController primaryController;
	
	  @FXML
	    private ListView<String> textField;


	    @FXML
	    private DatePicker datePicker;

	    @FXML
	    private TextField timeField;
	
	
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}
	  @FXML
	    void inspectorhomeclicked(ActionEvent event) {
		  
		  try {
	            // Load the LoginSignup.fxml file
	          
	            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/inspectorDashboard.fxml"));
	            Parent scene2Root = previousScene.load();
	        	
	            inspectorDashboard controller = previousScene.getController();
	            controller.setPrimaryController(primaryController);

	            // Get the current stage and set the new scene
	            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	            Scene scene = new Scene(scene2Root);
	            stage.setScene(scene);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	  
	  public void displayPendingItems() {
		    ObservableList<String> pendingItems = this.primaryController.inspectorDB.getPendingItems();
		    textField.setItems(pendingItems);
		}
	  
	  @FXML
	    private void handleBooking() {
	        String selectedItem = textField.getSelectionModel().getSelectedItem();
	        String selectedDate = datePicker.getValue() != null ? datePicker.getValue().toString() : null;
	        String enteredTime = timeField.getText();

	        if (selectedItem == null) {
	            showAlert("Error", "No item selected. Please select an item to book.");
	            return;
	        }

	        if (selectedDate == null || enteredTime.isEmpty()) {
	            showAlert("Error", "Please enter a valid date and time.");
	            return;
	        }

	        // If all fields are valid
	        showAlert("Success", "Booking Successful for:\n" + selectedItem + "\nDate: " + selectedDate + "\nTime: " + enteredTime);
	        int id=this.primaryController.extractID(selectedItem);
	        this.primaryController.inspectorDB.setItemStatusToInProgress(id);
	        this.primaryController.auth.insertLog("Item status in progress", this.primaryController.inspector.getEmail());
	        
	    }

	    // Utility method to display alerts
	    private void showAlert(String title, String message) {
	        Alert alert = new Alert(Alert.AlertType.INFORMATION, message, ButtonType.OK);
	        alert.setTitle(title);
	        alert.setHeaderText(null);
	        alert.showAndWait();
	    }
	  
	  @FXML
	    void contactusclicked(ActionEvent event) {
		  
		  
		  try {
	            // Load the LoginSignup.fxml file
	          
	            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/yourInfo.fxml"));
	            Parent scene2Root = previousScene.load();
	        	
	            yourInfo controller = previousScene.getController();
	            controller.setPrimaryController(primaryController);

	            // Get the current stage and set the new scene
	            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	            Scene scene = new Scene(scene2Root);
	            stage.setScene(scene);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
		  
	    }
	  
	  
	  
	  }
  
	  
	  