package controller;

import java.util.List;
import java.util.stream.Collectors;

import codingLayer.PrimaryController;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import model.Item;

public class pendingRequests{
	
	
	private PrimaryController primaryController;
	
	@FXML
	private ListView<String> listField;

	private List<Item> itemList; // Assume this is your list of items

	
	public void setPending() {
	    // Fetch or populate itemList with data from the database
	    itemList = null;
	    if(this.primaryController.user.seller!=null)
	    {
	    	itemList=this.primaryController.user.seller.items;
	    }

	    // Check if itemList is null or empty
	    if (itemList == null || itemList.isEmpty()) {
	        // If no items, display a message in the ListView
	        listField.setItems(FXCollections.observableArrayList("No items available"));
	    } else {
	        // Filter items where status is "Pending"
	        List<String> pendingItems = itemList.stream()
	        		.filter(item -> "Pending".equals(item.getStatus()) || "InProgress".equals(item.getStatus()))
	                .map(item -> String.format("ID: %d | Name: %s | Category: %s | Starting Price: %.2f | Current Price: %.2f | Status: %s",
	                        item.getItemID(),
	                        item.getItemName(),
	                        item.getCategory(),
	                        item.getStartingPrice(),
	                        item.getCurrentPrice(),
	                        item.getStatus()))
	                .collect(Collectors.toList());

	        // If there are pending items, display them, otherwise show "No pending items"
	        if (pendingItems.isEmpty()) {
	            listField.setItems(FXCollections.observableArrayList("No pending items"));
	        } else {
	            listField.setItems(FXCollections.observableArrayList(pendingItems));
	        }
	    }
	}
	
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}
	@FXML
    void backClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
            
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/SellDashboard.fxml"));
            Parent scene2Root = previousScene.load();
        	
            
            SellDashboard controller = previousScene.getController();
            controller.setPrimaryController(primaryController);

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
}