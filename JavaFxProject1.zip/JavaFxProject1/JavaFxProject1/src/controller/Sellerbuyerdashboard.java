package controller;

import codingLayer.PrimaryController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import model.User;

public class Sellerbuyerdashboard{
	
	@FXML
	private PrimaryController primaryController;
	
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}
	@FXML
    void ActiveBidsClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
        	
        	
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/ActiveBids.fxml"));
            Parent scene2Root = previousScene.load();
        	
            ActiveBids controller = previousScene.getController();
            controller.setPrimaryController(primaryController);
            controller.event=event;
            int userid=this.primaryController.user.getUserID();
            
        	controller.bidListView.setItems(this.primaryController.userDB.displayUserBids(userid));
        	System.out.println(controller.bidListView.getItems());

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	
	@FXML
    void SellClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/SellDashboard.fxml"));
            Parent scene2Root = previousScene.load();
        	
            SellDashboard controller = previousScene.getController();
            controller.setPrimaryController(primaryController);

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	@FXML
    void contactClicked(ActionEvent event) {
		try {
	        // Load the ContactUs.fxml file using FXMLLoader
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/ContactUs.fxml"));
	        Parent contactUsRoot = loader.load();

	        // Get the ContactUs controller and set the previous scene's path
	        ContactUs controller = loader.getController();
	        controller.setPreviousScene("/view/Sellerbuyerdashboard.fxml");
	        controller.setPrimaryController(primaryController);
	        

	        // Set the new scene
	        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	        Scene scene = new Scene(contactUsRoot);
	        stage.setScene(scene);
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
    }
	
	@FXML
    void infoClicked(ActionEvent event) {
		try {
	        // Load the ContactUs.fxml file using FXMLLoader
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/yourInfo.fxml"));
	        Parent contactUsRoot = loader.load();

	        // Get the ContactUs controller and set the previous scene's path
	        yourInfo controller = loader.getController();
	        controller.setPreviousScene("/view/Sellerbuyerdashboard.fxml");
	        controller.setPrimaryController(primaryController);
	        User user=this.primaryController.user;
	        String date=this.primaryController.auth.getRegistrationDate(user.getUserID());
	        controller.populateFields(user.getName(), user.getEmail(), user.getPhoneNumber(), date, user.getPassword());
	        

	        // Set the new scene
	        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	        Scene scene = new Scene(contactUsRoot);
	        stage.setScene(scene);
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
    }
	
	
	@FXML
    void boughtclicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/itemReports.fxml"));
            Parent scene2Root = previousScene.load();
        	
            itemReports controller = previousScene.getController();
            controller.setPrimaryController(primaryController);
            controller.role="buyer";
            controller.getReport();

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	
	@FXML
    void carsClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/carAuction.fxml"));
            Parent scene2Root = previousScene.load();
        	
            carAuction controller = previousScene.getController();
            controller.setPrimaryController(primaryController);
            controller.filterItemsByCategory("Car");

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	@FXML
    void watchlistClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/ActiveBids.fxml"));
            Parent scene2Root = previousScene.load();
        	
            ActiveBids controller = previousScene.getController();
            controller.setPrimaryController(primaryController);
            controller.event=event;
            int userid=this.primaryController.user.getUserID();
        	controller.bidListView.setItems(this.primaryController.userDB.displayUserBids(userid));
        	System.out.println(controller.bidListView.getItems());

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	
	@FXML
    void electronicsClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/electronicAuction.fxml"));
            Parent scene2Root = previousScene.load();
        	
            electronicAuction controller = previousScene.getController();
            controller.setPrimaryController(primaryController);
            controller.filterItemsByCategory("Electronic");

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	@FXML
    void artClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/artAuction.fxml"));
            Parent scene2Root = previousScene.load();
        	
            artAuction controller = previousScene.getController();
            controller.setPrimaryController(primaryController);
            controller.filterItemsByCategory("Art");

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	@FXML
    void antiqueClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/antiqueAuction.fxml"));
            Parent scene2Root = previousScene.load();
        	
            antiqueAuction controller = previousScene.getController();
            controller.setPrimaryController(primaryController);
            controller.filterItemsByCategory("Antique");

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}