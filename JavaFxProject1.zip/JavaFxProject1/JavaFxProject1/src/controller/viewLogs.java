package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import codingLayer.PrimaryController;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.Stage;



public class viewLogs
{
	
	@FXML
	private PrimaryController primaryController;

	  @FXML
	    private ListView<String> textField;
	  
	  
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}
	  @FXML
	    void adminhomeclicked(ActionEvent event) {
		  
		  try {
	            // Load the LoginSignup.fxml file
	            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/adminDashboard.fxml"));
	            Parent scene2Root = previousScene.load();
	        	
	            adminDashboard controller = previousScene.getController();
	            controller.setPrimaryController(primaryController);


	            // Get the current stage and set the new scene
	            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	            Scene scene = new Scene(scene2Root);
	            stage.setScene(scene);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	  
	  
	  public void displayPendingItems() {
		    ObservableList<String> pendingItems = this.primaryController.adminDB.getLogs();
		    textField.setItems(pendingItems);
		}
	  
	  
	  
	  
	
	  
	  
	  
	  }
  
	  
	  