package controller;

import java.util.ArrayList;

import codingLayer.PrimaryController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class SellDashboard{
	
	@FXML
	private PrimaryController primaryController;
	
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}
	@FXML
    void backClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
         
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/Sellerbuyerdashboard.fxml"));
            Parent scene2Root = previousScene.load();
        	
            Sellerbuyerdashboard controller = previousScene.getController();
            controller.setPrimaryController(primaryController);

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	@FXML
    void additemClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
          
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/addItem.fxml"));
            Parent scene2Root = previousScene.load();
        	
            addItem controller = previousScene.getController();
            controller.setPrimaryController(primaryController);

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	
	
	@FXML
	void activeitemsClicked(ActionEvent event) {
	    try {
	        // Load the ActiveItems.fxml file
	        FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/ActiveItems.fxml"));
	        Parent scene2Root = previousScene.load();

	        // Get the controller for ActiveItems
	        ActiveItems controller = previousScene.getController();
	        controller.setPrimaryController(primaryController);

	        // Check if the item list is null or empty
	        if (this.primaryController.user.seller == null ) {
	            // Pass an empty list and notify the controller
	            controller.setItemList(new ArrayList<>());
	        } else {
	            // Set the actual item list
	            controller.setItemList(this.primaryController.user.seller.items);
	        }

	        
	        // Get the current stage and set the new scene
	        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	        Scene scene = new Scene(scene2Root);
	        stage.setScene(scene);
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

	
	@FXML
	void PendingClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
       
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/pendingRequests.fxml"));
            Parent scene2Root = previousScene.load();
        	
            pendingRequests controller = previousScene.getController();
            controller.setPrimaryController(primaryController);
            controller.setPending();
            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	@FXML
	void solditemClicked(ActionEvent event)
	{
		  try {
	            // Load the LoginSignup.fxml file
	       
	            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/itemReports.fxml"));
	            Parent scene2Root = previousScene.load();
	        	
	            itemReports controller = previousScene.getController();
	            controller.setPrimaryController(primaryController);
	        controller.role="seller";
	        controller.getReport();
	        
	            // Get the current stage and set the new scene
	            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
	            Scene scene = new Scene(scene2Root);
	            stage.setScene(scene);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	}
	
}