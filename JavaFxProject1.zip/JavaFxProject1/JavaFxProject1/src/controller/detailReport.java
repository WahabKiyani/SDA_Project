package controller;

import codingLayer.PrimaryController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class detailReport
{
	@FXML
	private PrimaryController primaryController;
	
	@FXML private TextField buyerfield;
    @FXML private TextField sellerfield;
    @FXML private TextField pricefield;
    @FXML private TextField itemfield;
    @FXML private TextField datefield;
	
	public void setPrimaryController(PrimaryController primaryController2) {
		this.primaryController = primaryController2;
	}
	
	
	
	
	@FXML
    void backClicked(ActionEvent event) {
        try {
            // Load the LoginSignup.fxml file
            
            FXMLLoader previousScene = new FXMLLoader(getClass().getResource("/view/Sellerbuyerdashboard.fxml"));
            Parent scene2Root = previousScene.load();
        	
            Sellerbuyerdashboard controller = previousScene.getController();
            controller.setPrimaryController(primaryController);

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(scene2Root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	public void parseAndPrintReportDetails(String reportDetails) {
	    // Split the string into key-value pairs using ", " as the delimiter
	    String[] details = reportDetails.split(", ");
	    
	    // Initialize variables to store the parsed values
	    String itemId = "";
	    String price = "";
	    String bidderId = "";
	    String sellerId = "";
	    String date = "";
	    
	  

	    // Iterate over each key-value pair to extract relevant details
	    for (String detail : details) {
	        if (detail.startsWith("Item ID:")) {
	            itemId = detail.replace("Item ID:", "").trim();
	        } else if (detail.startsWith("Price:")) {
	            price = detail.replace("Price:", "").trim();
	        } else if (detail.startsWith("BidderId:")) {
	            bidderId = detail.replace("BidderId:", "").trim();
	        } else if (detail.startsWith("SellerId:")) {
	            sellerId = detail.replace("SellerId:", "").trim();
	        } else if (detail.startsWith("Date:")) {
	            date = detail.replace("Date:", "").trim();
	        }
	    }

	    
	    buyerfield.setText(this.primaryController.userDB.getBidderNameById(Integer.parseInt(bidderId)));
	   sellerfield.setText(this.primaryController.userDB.getSellerNameById(Integer.parseInt(sellerId)));
	     pricefield.setText(price);
	    itemfield.setText(this.primaryController.userDB.getItemNameById(Integer.parseInt(itemId)));
	     datefield.setText(date);
	     
	     
	    // Print the extracted details
	    System.out.println("Item ID: " + itemId);
	    System.out.println("Price: " + price);
	    System.out.println("Bidder ID: " + bidderId);
	    System.out.println("Seller ID: " + sellerId);
	    System.out.println("Date: " + date);
	}


}
